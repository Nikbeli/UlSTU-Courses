package com.example.demo.items.api;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.core.configuration.Constants;
import com.example.demo.items.model.ItemEntity;
import com.example.demo.items.service.ItemService;
import com.example.demo.types.service.TypeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping(Constants.API_URL + "/item")
public class ItemController {
    private final ItemService itemService;
    private final TypeService typeService;
    private final ModelMapper modelMapper;

    public ItemController(ItemService itemService, TypeService typeService, ModelMapper modelMapper) {
        this.itemService = itemService;
        this.typeService = typeService;
        this.modelMapper = modelMapper;
    }

    private ItemDto toDto(ItemEntity entity) {
        return modelMapper.map(entity, ItemDto.class);
    }

    private ItemEntity toEntity(ItemDto dto) {
        final ItemEntity entity = modelMapper.map(dto, ItemEntity.class);
        entity.setType(typeService.get(dto.getTypeId()));
        return entity;
    }

    @GetMapping
    public List<ItemDto> getAll(@RequestParam(name = "typeId", defaultValue = "0") Long typeId) {
        return itemService.getAll(typeId).stream().map(this::toDto).toList();
    }

    @GetMapping("/{id}")
    public ItemDto get(@PathVariable(name = "id") Long id) {
        return toDto(itemService.get(id));
    }

    @PostMapping
    public ItemDto create(@RequestBody @Valid ItemDto dto) {
        return toDto(itemService.create(toEntity(dto)));
    }

    @PutMapping("/{id}")
    public ItemDto update(@PathVariable(name = "id") Long id, @RequestBody ItemDto dto) {
        return toDto(itemService.update(id, toEntity(dto)));
    }

    @DeleteMapping("/{id}")
    public ItemDto delete(@PathVariable(name = "id") Long id) {
        return toDto(itemService.delete(id));
    }
}
