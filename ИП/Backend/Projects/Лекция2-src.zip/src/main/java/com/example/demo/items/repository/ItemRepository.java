package com.example.demo.items.repository;

import org.springframework.stereotype.Repository;

import com.example.demo.core.repository.MapRepository;
import com.example.demo.items.model.ItemEntity;

@Repository
public class ItemRepository extends MapRepository<ItemEntity> {
}
