package com.example.demo.items.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.core.error.NotFoundException;
import com.example.demo.items.model.ItemEntity;
import com.example.demo.items.repository.ItemRepository;

@Service
public class ItemService {
    private final ItemRepository repository;

    public ItemService(ItemRepository repository) {
        this.repository = repository;
    }

    public List<ItemEntity> getAll(Long typeId) {
        if (Objects.equals(typeId, 0L)) {
            return repository.getAll();
        }
        return repository.getAll().stream()
                .filter(item -> item.getType().getId().equals(typeId))
                .toList();
    }

    public ItemEntity get(Long id) {
        return Optional.ofNullable(repository.get(id))
                .orElseThrow(() -> new NotFoundException(id));
    }

    public ItemEntity create(ItemEntity entity) {
        return repository.create(entity);
    }

    public ItemEntity update(Long id, ItemEntity entity) {
        final ItemEntity existsEntity = get(id);
        existsEntity.setType(entity.getType());
        existsEntity.setPrice(entity.getPrice());
        existsEntity.setCount(entity.getCount());
        return repository.update(existsEntity);
    }

    public ItemEntity delete(Long id) {
        final ItemEntity existsEntity = get(id);
        return repository.delete(existsEntity);
    }
}
