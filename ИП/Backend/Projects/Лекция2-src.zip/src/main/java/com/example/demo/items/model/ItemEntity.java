package com.example.demo.items.model;

import java.util.Objects;

import com.example.demo.core.model.BaseEntity;
import com.example.demo.types.model.TypeEntity;

public class ItemEntity extends BaseEntity {
    private TypeEntity type;
    private Double price;
    private Integer count;

    public ItemEntity() {
        super();
    }

    public ItemEntity(Long id, TypeEntity type, Double price, Integer count) {
        super(id);
        this.type = type;
        this.price = price;
        this.count = count;
    }

    public TypeEntity getType() {
        return type;
    }

    public void setType(TypeEntity type) {
        this.type = type;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, type, price, count);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        final ItemEntity other = (ItemEntity) obj;
        return Objects.equals(other.getId(), id)
                && Objects.equals(other.getType(), type)
                && Objects.equals(other.getPrice(), price)
                && Objects.equals(other.getCount(), count);
    }
}
