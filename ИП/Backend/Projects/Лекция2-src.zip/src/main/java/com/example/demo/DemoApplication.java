package com.example.demo;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.items.model.ItemEntity;
import com.example.demo.items.service.ItemService;
import com.example.demo.types.model.TypeEntity;
import com.example.demo.types.service.TypeService;

@SpringBootApplication
public class DemoApplication implements CommandLineRunner {
	private final Logger log = LoggerFactory.getLogger(DemoApplication.class);

	private final TypeService typeService;
	private final ItemService itemService;

	public DemoApplication(TypeService typeService, ItemService itemService) {
		this.typeService = typeService;
		this.itemService = itemService;
	}

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		if (args.length > 0 && Objects.equals("--populate", args[0])) {
			log.info("Create default types values");
			final var type1 = typeService.create(new TypeEntity(null, "Ноутбук"));
			final var type2 = typeService.create(new TypeEntity(null, "Телефон"));
			final var type3 = typeService.create(new TypeEntity(null, "Игровая приставка"));

			log.info("Create default items values");
			itemService.create(new ItemEntity(null, type1, 49999.00, 20));
			itemService.create(new ItemEntity(null, type1, 129999.00, 3));
			itemService.create(new ItemEntity(null, type2, 15450.50, 30));
			itemService.create(new ItemEntity(null, type2, 69900.50, 10));
			itemService.create(new ItemEntity(null, type2, 150000.00, 6));
			itemService.create(new ItemEntity(null, type3, 75000.00, 6));
			itemService.create(new ItemEntity(null, type3, 67800.00, 3));
		}
	}
}
