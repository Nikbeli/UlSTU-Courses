import { resolve } from "path";
// eslint-disable-next-line import/no-extraneous-dependencies
import { defineConfig } from "vite";

const src = "src/main/resources/webapp";

export default defineConfig({
    root: src,
    build: {
        sourcemap: true,
        emptyOutDir: true,
        rollupOptions: {
            input: {
                main: resolve(__dirname, src, "index.html"),
            },
        },
        outDir: "../../../../build/resources/main/static",
    },
});
