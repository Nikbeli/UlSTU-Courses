Swagger UI: \
http://localhost:8080/swagger-ui/index.html

H2 Console: \
http://localhost:8080/h2-console

JDBC URL: jdbc:h2:file:./data \
User Name: sa \
Password: password

Для профиля prod необходимо наличие СУБД PostgreSQL и БД demo-app.

Создать БД можно так: \
createdb -h localhost -U postgres demo-app

Пример запуска приложения с профилем prod и заполнением БД с помощью аргумента --populate:

- nix => bash ./gradlew.bat -Pprod -Pargs='--populate'
- windows =>.\gradlew.bat -Pprod -Pargs='--populate'

Почитать:

- Security with Spring https://www.baeldung.com/security-spring
- Spring Security https://docs.spring.io/spring-security/reference/index.html
- JWT-аутентификация при помощи Spring Boot 3 и Spring Security 6 https://habr.com/ru/articles/784508/
