import { hiddenClass, tokenKey, usernameKey } from "./config";

const login = () => {
    const makeLogin = async (username, password) => {
        const response = await fetch(
            `http://localhost:8080/login?login=${username}&password=${password}`,
            { method: 'POST' },
        );
        const token = await response.text();
        if (response.status === 200) {
            localStorage.setItem(tokenKey, token);
            localStorage.setItem(usernameKey, username);
        } else {
            makeLogout();
        }
    };

    const makeLogout = () => {
        localStorage.removeItem(tokenKey);
        localStorage.removeItem(usernameKey);
    };

    return {
        login: makeLogin,
        logout: makeLogout,
    };
};

const loginForm = (loginCallback, logoutCallback) => {
    const loginHelper = login();

    const form = document.getElementById("login-form");
    const loginInput = form.querySelector("[id='username']");
    const passwordInput = form.querySelector("[id='password']");

    const logoutButton = document.getElementById("logout");
    const userNameSpan = document.getElementById("username");

    const onLogin = () => {
        if (localStorage.getItem(tokenKey) !== null) {
            logoutButton.classList.remove(hiddenClass);
            form.classList.add(hiddenClass);
            userNameSpan.innerText = ` (${localStorage.getItem(usernameKey)})`;

            if (loginCallback) {
                loginCallback();
            }
        }
    };

    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        event.stopPropagation();

        await loginHelper.login(loginInput.value, passwordInput.value);

        onLogin();

        loginInput.value = "";
        passwordInput.value = "";
    });

    logoutButton.addEventListener("click", () => {
        if (!confirm('Вы уверены?')) {
            return;
        }

        loginHelper.logout();
        logoutButton.classList.add(hiddenClass);
        form.classList.remove(hiddenClass);
        userNameSpan.innerText = "";

        if (logoutCallback) {
            logoutCallback();
        }
    });

    onLogin();
};

export default loginForm;
