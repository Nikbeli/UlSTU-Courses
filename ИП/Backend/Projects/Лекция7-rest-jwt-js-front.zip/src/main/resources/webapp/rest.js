import { tokenKey } from "./config";

const rest = () => {
    const orders = "order";
    const users = "user";

    const getData = async (entity, token) => {
        const params = {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        };
        try {
            const response = await fetch(`http://localhost:8080/api/1.0/${entity}?size=100`, token ? params : undefined);
            if (!response.ok) {
                return null;
            }
            return await response.json();
        } catch (e) {
            console.error(e);
            return null;
        }
    };

    const getToken = () => localStorage.getItem(tokenKey);

    return {
        ordersWithoutToken: () => getData(orders),
        ordersWithToken: () => getData(orders, getToken()),
        usersWithoutToken: () => getData(users),
        usersWithToken: () => getData(users, getToken()),
    };
};

const loadRestData = async (app) => {
    const addData = (title, data) => {
        const head = `<h3>${title}</h3>`;
        const content = data
            ? data.items.map((item) => {
                const order = JSON.stringify(item);
                const image = item.extension
                    ? `
                    <img src="http://localhost:8080/resources/image/order-${item.id}.${item.extension}" 
                        alt="image-${item.id}" height="80" />
                    `
                    : "";
                return `<p>${order}</p>${image}`;
            }).join("")
            : "Ошибка получения данных";
        // eslint-disable-next-line no-param-reassign
        app.innerHTML += `<div>${head}<p>${content || 'Пусто'}</p></div>`;
    };

    const http = rest();

    const orders1 = await http.ordersWithoutToken();
    const orders2 = await http.ordersWithToken();
    const users1 = await http.usersWithoutToken();
    const users2 = await http.usersWithToken();

    console.log("orders without token ", orders1);
    console.log("orders with token ", orders2);
    console.log("users without token ", users1);
    console.log("users with token ", users2);

    addData("Заказы без токена", orders1);
    addData("Заказы с токеном", orders2);
    addData("Пользователи без токена", users1);
    addData("Пользователи с токеном", users2);
};

export default loadRestData;
