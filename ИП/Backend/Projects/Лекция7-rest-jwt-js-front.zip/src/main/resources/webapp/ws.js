// eslint-disable-next-line import/no-unresolved
import { Client } from '@stomp/stompjs';
import { tokenKey } from './config';

const wsClient = () => {
    let messageCallback = null;
    let stompClient = null;

    const createClient = () => {
        const client = new Client({
            brokerURL: "ws://localhost:8080/ws",
            connectHeaders: {
                Authorization: `Bearer ${localStorage.getItem(tokenKey)}`,
            },
        });

        const proceedMessage = (message) => {
            const data = JSON.parse(message.body);
            console.log(data);
            if (messageCallback) {
                messageCallback(data);
            }
        };

        client.onConnect = (frame) => {
            console.log(`Connected: ${frame}`);
            client.subscribe('/topic/messages', proceedMessage);
            client.subscribe('/user/topic/messages', proceedMessage);
        };

        client.onWebSocketError = (error) => {
            console.error('Error with websocket', error);
        };

        client.onStompError = (frame) => {
            console.error(`Broker reported error: ${frame.headers.message}`);
            if (frame.body) {
                console.error(`Additional details: ${frame.body}`);
            }
        };

        return client;
    };

    const connect = () => {
        if (stompClient && stompClient.active) {
            return;
        }
        stompClient = createClient();
        stompClient.activate();
        console.log("Connected");
    };

    const disconnect = () => {
        if (stompClient && !stompClient.active) {
            return;
        }
        stompClient.deactivate();
        stompClient = null;
        console.log("Disconnected");
    };

    const sendMessage = (message, toUser) => {
        if (stompClient && !stompClient.active) {
            console.error("Connection is not activated yet");
            return;
        }
        if (!message.trim()) {
            return;
        }
        const userUrl = toUser ? `/${toUser}` : '';
        stompClient.publish({
            destination: `/app/messages${userUrl}`,
            body: message,
        });
    };

    return {
        sendToAll: (message) => sendMessage(message),
        sendToUser: (message, user) => sendMessage(message, user),
        setCallback: (callback) => { messageCallback = callback; },
        connect,
        disconnect,
    };
};

export default wsClient;
