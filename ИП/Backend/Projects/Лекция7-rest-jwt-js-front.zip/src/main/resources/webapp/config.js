export const tokenKey = "token";
export const usernameKey = "username";
export const hiddenClass = "d-none";
