import { hiddenClass, usernameKey } from "./config";

export const chat = async (wsClient, messages, messageBox) => {
    const format = (date) => {
        const d = new Date(date);
        let month = `${d.getMonth() + 1}`;
        let day = `${d.getDate()}`;
        const year = d.getFullYear();
        if (month.length < 2) {
            month = `0${month}`;
        }
        if (day.length < 2) {
            day = `0${day}`;
        }
        return [day, month, year].join('.');
    };

    const addOutMessage = (message) => {
        const username = localStorage.getItem(usernameKey);
        // eslint-disable-next-line no-param-reassign
        messages.innerHTML
            += `<div class="message d-flex flex-row justify-content-end mb-4">
                        <div class="p-3 me-3 border message-body message-out">
                            <p class="fw-semibold m-0">${username}</p>
                            <p class="small m-0">${message}</p>
                            <p class="fw-light small m-0 text-end">${format(new Date())}</p>
                        </div>
                        <img class="message-avatar" src="/batman.svg" alt="avatar">
                    </div>`;
        // eslint-disable-next-line no-param-reassign
        messages.scrollTop = messages.scrollHeight;
    };

    const addInMessage = (message) => {
        if (message.author === localStorage.getItem(usernameKey)) {
            return;
        }
        // eslint-disable-next-line no-param-reassign
        messages.innerHTML
            += `<div class="message d-flex flex-row justify-content-start mb-4">
                        <img class="message-avatar" src="/einstein.svg" alt="avatar">
                        <div class="p-3 ms-3 message-body message-in">
                            <p class="fw-semibold m-0">${message.author}</p>
                            <p class="small m-0">${message.text}</p>
                            <p class="fw-light small m-0 text-end">${format(message.date)}</p>
                        </div>
                    </div>`;
        // eslint-disable-next-line no-param-reassign
        messages.scrollTop = messages.scrollHeight;
    };

    const sendMessage = (message, toUser) => {
        if (!message.trim()) {
            return;
        }
        if (toUser) {
            wsClient.sendToUser(message, toUser);
        } else {
            wsClient.sendToAll(message);
        }
        addOutMessage(message);
    };

    messageBox.addEventListener("keydown", (event) => {
        if (event.code === "Enter") {
            event.preventDefault();
            event.stopPropagation();
            const message = messageBox.value;
            if (message.startsWith("@")) {
                const splitted = message.split(" ");
                if (splitted.length < 2) {
                    return;
                }
                const userName = splitted.shift().replaceAll("@", "");
                sendMessage(splitted.join(" "), userName);
            } else {
                sendMessage(message);
            }
            // eslint-disable-next-line no-param-reassign
            messageBox.value = "";
        }
    });

    if (wsClient) {
        wsClient.setCallback(addInMessage);
    }
};

export const chatToggle = (chatContainer, chatHeader, chatBody) => {
    const toggleChat = () => {
        const closedClass = "closed-chat";
        const chatVisible = chatContainer.classList.contains(closedClass);
        if (chatVisible) {
            chatBody.classList.remove(hiddenClass);
            chatContainer.classList.remove(closedClass);
        } else {
            chatBody.classList.add(hiddenClass);
            chatContainer.classList.add(closedClass);
        }
    };

    chatHeader.addEventListener("click", toggleChat);

    toggleChat();

    return { toggleChat };
};
