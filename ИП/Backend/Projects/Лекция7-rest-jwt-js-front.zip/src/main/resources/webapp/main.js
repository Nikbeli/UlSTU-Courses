// eslint-disable-next-line import/no-extraneous-dependencies
import "bootstrap-icons/font/bootstrap-icons.min.css";
// eslint-disable-next-line import/no-extraneous-dependencies
import "bootstrap/dist/css/bootstrap.min.css";
// eslint-disable-next-line import/no-extraneous-dependencies
import "bootstrap/dist/js/bootstrap.bundle.min";
import { chat, chatToggle } from "./chat";
import { hiddenClass } from "./config";
import loginForm from "./login";
import loadRestData from "./rest";
import './style.css';
import wsClient from "./ws";

const chatContainer = document.getElementById("chat-container");
const messages = document.getElementById("messages");
const messageBox = document.getElementById("message-box");
const chatHeader = document.querySelector("#chat .card-header");
const chatBody = document.querySelector("#chat .card-body");
const app = document.getElementById("app");

const wsHelper = wsClient();
chat(wsHelper, messages, messageBox);
chatToggle(chatContainer, chatHeader, chatBody);

const onLogin = () => {
    chatContainer.classList.remove(hiddenClass);
    messageBox.value = "";
    messages.innerHTML = "";
    wsHelper.connect();
    loadRestData(app);
};

const onLogout = () => {
    chatContainer.classList.add(hiddenClass);
    app.innerHTML = "";
    wsHelper.disconnect();
};

loginForm(onLogin, onLogout);

document.getElementById("footer-date").innerHTML += new Date().getFullYear();
