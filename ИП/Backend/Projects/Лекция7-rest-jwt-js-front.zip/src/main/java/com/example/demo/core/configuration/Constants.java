package com.example.demo.core.configuration;

public class Constants {
    public static final String SEQUENCE_NAME = "hibernate_sequence";

    public static final String API_URL = "/api/1.0";

    public static final String DEFAULT_PAGE_SIZE = "5";

    public static final String LOGIN_URL = "/login";
    public static final String SIGNUP_URL = "/signup";

    public static final String DEFAULT_PASSWORD = "123456";

    private Constants() {
    }
}
