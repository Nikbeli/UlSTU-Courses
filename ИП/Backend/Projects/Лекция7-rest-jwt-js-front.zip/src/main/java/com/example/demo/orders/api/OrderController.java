package com.example.demo.orders.api;

import java.nio.file.Path;
import java.util.List;
import java.util.Set;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.core.api.PageDto;
import com.example.demo.core.api.PageDtoMapper;
import com.example.demo.core.configuration.Constants;
import com.example.demo.core.file.FileHelper;
import com.example.demo.core.security.UserPrincipal;
import com.example.demo.orders.model.OrderEntity;
import com.example.demo.orders.model.OrderGrouped;
import com.example.demo.orders.service.OrderService;
import com.example.demo.types.service.TypeService;

import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@RestController
@RequestMapping(Constants.API_URL + "/order")
public class OrderController {
    private final Set<String> allow = Set.of("jpg", "jpeg", "png", "svg");

    private final OrderService orderService;
    private final TypeService typeService;
    private final ModelMapper modelMapper;
    private final ServletContext servletContext;

    public OrderController(
            OrderService orderService,
            TypeService typeService,
            ModelMapper modelMapper,
            ServletContext servletContext) {
        this.orderService = orderService;
        this.typeService = typeService;
        this.modelMapper = modelMapper;
        this.servletContext = servletContext;
    }

    private OrderDto toDto(OrderEntity entity) {
        final OrderDto dto = modelMapper.map(entity, OrderDto.class);
        if (entity.getImage() != null && entity.getImage().length > 0) {
            final Path contextPath = Path.of(servletContext.getRealPath("/"));
            FileHelper.saveToFile(
                    contextPath,
                    entity.getId(),
                    entity.getImageExtension(),
                    entity.getImage());
        }
        return dto;
    }

    private OrderEntity toEntity(OrderDto dto, MultipartFile image) {
        final String extension = FileHelper.getExtension(image);
        if (!allow.contains(extension.toLowerCase())) {
            throw new IllegalArgumentException(
                    String.format("Only %s files", String.join(", ", allow)));
        }
        final OrderEntity entity = modelMapper.map(dto, OrderEntity.class);
        entity.setType(typeService.get(dto.getTypeId()));
        entity.setImageExtension(extension);
        entity.setImage(FileHelper.getFileBytes(image));
        return entity;
    }

    private OrderGroupedDto toGroupedDto(OrderGrouped entity) {
        return modelMapper.map(entity, OrderGroupedDto.class);
    }

    @GetMapping
    public PageDto<OrderDto> getAll(
            @RequestParam(name = "typeId", defaultValue = "0") Long typeId,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = Constants.DEFAULT_PAGE_SIZE) int size,
            @AuthenticationPrincipal UserPrincipal principal) {
        return PageDtoMapper.toDto(orderService.getAll(principal.getId(), typeId, page, size), this::toDto);
    }

    @GetMapping("/{id}")
    public OrderDto get(
            @PathVariable(name = "id") Long id,
            @AuthenticationPrincipal UserPrincipal principal) {
        return toDto(orderService.get(principal.getId(), id));
    }

    @GetMapping(value = "/{id}/image", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public byte[] getOrderImage(
            @PathVariable(name = "id") Long id,
            @AuthenticationPrincipal UserPrincipal principal) {
        return orderService.get(principal.getId(), id).getImage();
    }

    @GetMapping(value = "/{id}/image/download", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public byte[] downloadOrderImage(
            @PathVariable(name = "id") Long id,
            @AuthenticationPrincipal UserPrincipal principal,
            HttpServletResponse response) {
        final OrderEntity order = orderService.get(principal.getId(), id);
        response.addHeader(HttpHeaders.CONTENT_DISPOSITION,
                String.format("attachment; filename=order-%s.%s", id, order.getImageExtension()));
        return order.getImage();
    }

    @PostMapping(consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public OrderDto create(
            @RequestPart @Valid OrderDto dto,
            @RequestPart(name = "file") MultipartFile image,
            @AuthenticationPrincipal UserPrincipal principal) {
        return toDto(orderService.create(principal.getId(), toEntity(dto, image)));
    }

    @PutMapping(value = "/{id}", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public OrderDto update(
            @PathVariable(name = "id") Long id,
            @RequestPart @Valid OrderDto dto,
            @RequestPart(name = "file") MultipartFile image,
            @AuthenticationPrincipal UserPrincipal principal) {
        return toDto(orderService.update(principal.getId(), id, toEntity(dto, image)));
    }

    @DeleteMapping("/{id}")
    public OrderDto delete(
            @PathVariable(name = "id") Long id,
            @AuthenticationPrincipal UserPrincipal principal) {
        return toDto(orderService.delete(principal.getId(), id));
    }

    @GetMapping("/total")
    public List<OrderGroupedDto> getMethodName(@AuthenticationPrincipal UserPrincipal principal) {
        return orderService.getTotal(principal.getId()).stream()
                .map(this::toGroupedDto)
                .toList();
    }

}
