package com.example.demo.users.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.StreamSupport;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.example.demo.core.configuration.Constants;
import com.example.demo.core.error.NotFoundException;
import com.example.demo.core.jwt.JwtException;
import com.example.demo.core.jwt.JwtProvider;
import com.example.demo.core.security.UserPrincipal;
import com.example.demo.subscriptions.model.SubscriptionEntity;
import com.example.demo.subscriptions.service.SubscriptionService;
import com.example.demo.users.model.UserEntity;
import com.example.demo.users.model.UserRole;
import com.example.demo.users.repository.UserRepository;
import com.example.demo.usersubscription.model.UserSubscriptionEntity;

@Service
public class UserService implements UserDetailsService {
    private final UserRepository repository;
    private final SubscriptionService subscriptionService;
    private final PasswordEncoder passwordEncoder;
    private final JwtProvider jwtProvider;

    public UserService(
            UserRepository repository,
            SubscriptionService subscriptionService,
            PasswordEncoder passwordEncoder,
            JwtProvider jwtProvider) {
        this.repository = repository;
        this.subscriptionService = subscriptionService;
        this.passwordEncoder = passwordEncoder;
        this.jwtProvider = jwtProvider;
    }

    private void checkLogin(Long id, String login) {
        final Optional<UserEntity> existsUser = repository.findByLoginIgnoreCase(login);
        if (existsUser.isPresent() && !existsUser.get().getId().equals(id)) {
            throw new IllegalArgumentException(
                    String.format("User with login %s is already exists", login));
        }
    }

    @Transactional(readOnly = true)
    public List<UserEntity> getAll() {
        return StreamSupport.stream(repository.findAll().spliterator(), false).toList();
    }

    @Transactional(readOnly = true)
    public Page<UserEntity> getAll(int page, int size) {
        return repository.findAll(PageRequest.of(page, size));
    }

    @Transactional(readOnly = true)
    public UserEntity get(long id) {
        return repository.findById(id)
                .orElseThrow(() -> new NotFoundException(UserEntity.class, id));
    }

    @Transactional(readOnly = true)
    public UserEntity getByLogin(String login) {
        return repository.findByLoginIgnoreCase(login)
                .orElseThrow(() -> new IllegalArgumentException("Invalid login"));
    }

    @Transactional
    public UserEntity create(UserEntity entity) {
        if (entity == null) {
            throw new IllegalArgumentException("Entity is null");
        }
        checkLogin(null, entity.getLogin());
        final String password = Optional.ofNullable(entity.getPassword()).orElse("");
        entity.setPassword(
                passwordEncoder.encode(
                        StringUtils.hasText(password.strip()) ? password : Constants.DEFAULT_PASSWORD));
        entity.setRole(Optional.ofNullable(entity.getRole()).orElse(UserRole.USER));
        repository.save(entity);
        subscriptionService.getAll().forEach(subscription -> {
            final UserSubscriptionEntity userSubscription = new UserSubscriptionEntity(entity, subscription, true);
            userSubscription.setUser(entity);
            userSubscription.setSubscription(subscription);
        });
        return repository.save(entity);
    }

    @Transactional
    public UserEntity update(long id, UserEntity entity) {
        final UserEntity existsEntity = get(id);
        checkLogin(id, entity.getLogin());
        existsEntity.setLogin(entity.getLogin());
        repository.save(existsEntity);
        return existsEntity;
    }

    @Transactional
    public UserEntity delete(long id) {
        final UserEntity existsEntity = get(id);
        repository.delete(existsEntity);
        return existsEntity;
    }

    @Transactional(readOnly = true)
    public List<SubscriptionEntity> getUserSubscriptions(long id) {
        return get(id).getUserSubscriptions().stream()
                .filter(UserSubscriptionEntity::isActive)
                .map(UserSubscriptionEntity::getSubscription)
                .toList();
    }

    private List<SubscriptionEntity> changeUserSubscriptionsState(
            UserEntity existsUser,
            List<Long> subscriptionsIds,
            boolean state) {
        return existsUser.getUserSubscriptions().stream()
                .filter(subscription -> Objects.nonNull(subscription.getSubscription()))
                .filter(subscription -> subscriptionsIds.contains(subscription.getSubscription().getId()))
                .filter(subscription -> subscription.isActive() == !state)
                .map(subscription -> {
                    subscription.setActive(state);
                    return subscription.getSubscription();
                })
                .toList();
    }

    @Transactional
    public List<SubscriptionEntity> enableUserSubscriptions(long id, List<Long> subscriptionsIds) {
        final UserEntity existsUser = get(id);
        final List<SubscriptionEntity> changedSubscriptions = changeUserSubscriptionsState(
                existsUser, subscriptionsIds, true);
        repository.save(existsUser);
        return changedSubscriptions;
    }

    @Transactional
    public List<SubscriptionEntity> disableUserSubscriptions(long id, List<Long> subscriptionsIds) {
        final UserEntity existsUser = get(id);
        final List<SubscriptionEntity> changedSubscriptions = changeUserSubscriptionsState(
                existsUser, subscriptionsIds, false);
        repository.save(existsUser);
        return changedSubscriptions;
    }

    @Transactional
    public List<SubscriptionEntity> deleteAllUserSubscriptions(long id) {
        final UserEntity existsUser = get(id);
        final List<UserSubscriptionEntity> subscriptions = existsUser.getUserSubscriptions().stream()
                .filter(subscription -> Objects.nonNull(subscription.getSubscription()))
                .toList();
        subscriptions.forEach(existsUser::deleteSubscription);
        repository.save(existsUser);
        return subscriptions.stream()
                .map(UserSubscriptionEntity::getSubscription)
                .toList();
    }

    @Transactional(readOnly = true)
    public UserDetails getByToken(String token) {
        if (!jwtProvider.isTokenValid(token)) {
            throw new JwtException("Bad token");
        }
        final String userLogin = jwtProvider.getLoginFromToken(token)
                .orElseThrow(() -> new JwtException("Token is not contain Login"));
        return loadUserByUsername(userLogin);
    }

    @Transactional(readOnly = true)
    public String login(String login, String password) {
        final UserEntity existsUser = getByLogin(login);
        if (!passwordEncoder.matches(password, existsUser.getPassword())) {
            throw new IllegalArgumentException("Invalid login");
        }
        return jwtProvider.generateToken(existsUser.getLogin());

    }

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        final UserEntity existsUser = getByLogin(username);
        return new UserPrincipal(existsUser);
    }
}
