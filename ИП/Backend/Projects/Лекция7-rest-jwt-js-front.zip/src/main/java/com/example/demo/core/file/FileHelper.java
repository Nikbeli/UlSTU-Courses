package com.example.demo.core.file;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

public class FileHelper {
    private static final Logger log = LoggerFactory.getLogger(FileHelper.class);

    private FileHelper() {
    }

    public static String getExtension(MultipartFile file) {
        if (file.isEmpty()) {
            return null;
        }
        final String fileName = file.getOriginalFilename();
        if (fileName == null) {
            return null;
        }
        final int lastIndex = fileName.lastIndexOf('.');
        return fileName.substring(lastIndex, fileName.length()).replaceFirst("\\.", "");
    }

    public static byte[] getFileBytes(MultipartFile file) {
        if (file.isEmpty()) {
            throw new IllegalArgumentException("Empty file");
        }
        try {
            return file.getBytes();
        } catch (IOException e) {
            log.error("File upload error", e);
            return new byte[0];
        }
    }

    public static String saveToFile(Path path, long id, String extension, byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }
        try {
            final Path dir = Path.of(
                    path.toFile().getAbsolutePath(),
                    "resources/image");
            if (!Files.exists(dir)) {
                Files.createDirectories(dir);
            }
            final Path temp = Path.of(
                    dir.toFile().getAbsolutePath(),
                    String.format("order-%s.%s", id, extension));
            Files.write(temp, bytes);
            return temp.toFile().getAbsolutePath();
        } catch (IOException e) {
            throw new InternalError(e);
        }
    }
}
