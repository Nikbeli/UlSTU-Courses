package com.example.demo.ws.service;

import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

@Service
public class MessageService {
    private final SimpMessagingTemplate messagingTemplate;

    public MessageService(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    public <T> T sendMessageToAll(String destination, T message) {
        messagingTemplate.convertAndSend(destination, message);
        return message;
    }

    public <T> T sendMessageToUser(String destination, String user, T message) {
        messagingTemplate.convertAndSendToUser(user, destination, message);
        return message;
    }
}
