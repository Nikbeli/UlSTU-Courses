package com.example.demo.ws.scheduler;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.example.demo.ws.api.MessageController;
import com.example.demo.ws.api.MessageDto;
import com.example.demo.ws.service.MessageService;

@Component
public class MessageScheduler {
    private final MessageService messageService;

    public MessageScheduler(MessageService messageService) {
        this.messageService = messageService;
    }

    @Scheduled(cron = "*/30 * * * * ?", zone = "Europe/Samara")
    public void scheduledServiceMessages() {
        messageService.sendMessageToAll(
                MessageController.MESSAGES_TOPIC,
                new MessageDto("service", "Scheduled message"));
    }
}
