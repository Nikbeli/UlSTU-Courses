package com.example.demo.ws.api;

import java.util.Date;

public class MessageDto {
    private final String author;
    private final Date date;
    private final String text;

    public MessageDto(String author, String text) {
        this.author = author;
        this.date = new Date();
        this.text = text;
    }

    public String getAuthor() {
        return author;
    }

    public Date getDate() {
        return date;
    }

    public String getText() {
        return text;
    }
}
