package com.example.demo.orders.api;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class OrderDto {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;
    @NotNull
    @Min(1)
    private Long typeId;
    @NotNull
    @Min(1)
    private Double price;
    @NotNull
    @Min(1)
    private Integer count;
    @JsonProperty(value = "extension", access = JsonProperty.Access.READ_ONLY)
    private String imageExtension;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTypeId() {
        return typeId;
    }

    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getImageExtension() {
        return imageExtension;
    }

    public void setImageExtension(String imageExtension) {
        this.imageExtension = imageExtension;
    }

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    public Double getSum() {
        return price * count;
    }
}
