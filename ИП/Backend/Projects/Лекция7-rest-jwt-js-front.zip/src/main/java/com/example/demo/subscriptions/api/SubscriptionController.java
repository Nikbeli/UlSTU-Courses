package com.example.demo.subscriptions.api;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.core.configuration.Constants;
import com.example.demo.subscriptions.model.SubscriptionEntity;
import com.example.demo.subscriptions.service.SubscriptionService;
import com.example.demo.users.model.UserRole;

import jakarta.validation.Valid;

@RestController
@Secured(value = UserRole.Secured.ADMIN)
@RequestMapping(Constants.API_URL + "/subsciption")
public class SubscriptionController {
    private final SubscriptionService subscriptionService;
    private final ModelMapper modelMapper;

    public SubscriptionController(SubscriptionService subscriptionService, ModelMapper modelMapper) {
        this.subscriptionService = subscriptionService;
        this.modelMapper = modelMapper;
    }

    private SubscriptionDto toDto(SubscriptionEntity entity) {
        return modelMapper.map(entity, SubscriptionDto.class);
    }

    private SubscriptionEntity toEntity(SubscriptionDto dto) {
        return modelMapper.map(dto, SubscriptionEntity.class);
    }

    @GetMapping
    public List<SubscriptionDto> getAll() {
        return subscriptionService.getAll().stream()
                .map(this::toDto)
                .toList();
    }

    @GetMapping("/{id}")
    public SubscriptionDto get(@PathVariable(name = "id") Long id) {
        return toDto(subscriptionService.get(id));
    }

    @PostMapping
    public SubscriptionDto create(@RequestBody @Valid SubscriptionDto dto) {
        return toDto(subscriptionService.create(toEntity(dto)));
    }

    @PutMapping("/{id}")
    public SubscriptionDto update(
            @PathVariable(name = "id") Long id,
            @RequestBody @Valid SubscriptionDto dto) {
        return toDto(subscriptionService.update(id, toEntity(dto)));
    }

    @DeleteMapping("/{id}")
    public SubscriptionDto delete(@PathVariable(name = "id") Long id) {
        return toDto(subscriptionService.delete(id));
    }
}
