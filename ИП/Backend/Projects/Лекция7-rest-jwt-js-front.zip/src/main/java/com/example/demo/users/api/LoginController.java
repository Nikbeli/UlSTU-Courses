package com.example.demo.users.api;

import java.util.Objects;

import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.core.configuration.Constants;
import com.example.demo.users.model.UserEntity;
import com.example.demo.users.service.UserService;

@RestController
public class LoginController {
    private final UserService userService;

    public LoginController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping(Constants.LOGIN_URL)
    public String login(
            @RequestParam(name = "login") String login,
            @RequestParam(name = "password") String password) {
        return userService.login(login, password);
    }

    @PostMapping(Constants.SIGNUP_URL)
    public boolean signup(
            @RequestParam(name = "login") String login,
            @RequestParam(name = "password") String password,
            @RequestParam(name = "password2") String password2) {
        if (!StringUtils.hasText(login)) {
            throw new IllegalArgumentException("Invalid login");
        }
        if (!StringUtils.hasText(password)) {
            throw new IllegalArgumentException("Invalid password");
        }
        if (!Objects.equals(password, password2)) {
            throw new IllegalArgumentException("Passwords are not equals");
        }
        final UserEntity user = new UserEntity(login, password);
        userService.create(user);
        return true;
    }
}
