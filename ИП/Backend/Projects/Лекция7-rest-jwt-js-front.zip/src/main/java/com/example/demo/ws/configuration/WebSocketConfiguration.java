package com.example.demo.ws.configuration;

import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authorization.AuthorizationManager;
import org.springframework.security.config.annotation.web.socket.EnableWebSocketSecurity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.messaging.access.intercept.MessageMatcherDelegatingAuthorizationManager;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

import com.example.demo.core.jwt.JwtFilter;
import com.example.demo.users.service.UserService;

@Order(Ordered.HIGHEST_PRECEDENCE)
@Configuration
@EnableWebSocketMessageBroker
@EnableWebSocketSecurity
public class WebSocketConfiguration implements WebSocketMessageBrokerConfigurer {
    private static final String APP_PREFIX = "/app";
    public static final String ENDPOINT = "/ws";
    public static final String TOPIC_PREFIX = "/topic";

    private final UserService userService;

    public WebSocketConfiguration(UserService userService) {
        this.userService = userService;
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint(ENDPOINT).setAllowedOrigins("*");
    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.enableSimpleBroker(TOPIC_PREFIX);
        registry.setApplicationDestinationPrefixes(APP_PREFIX);
    }

    private static String getTokenFromHeaders(Map<String, List<String>> nativeHeaders) {
        final List<String> headers = nativeHeaders.get(JwtFilter.AUTHORIZATION);
        if (headers == null || headers.isEmpty()) {
            throw new IllegalArgumentException("Auth header is not found");
        }
        return JwtFilter.getToken(headers.get(0));
    }

    @Override
    public void configureClientInboundChannel(ChannelRegistration registration) {
        registration.interceptors(new ChannelInterceptor() {
            @Override
            public Message<?> preSend(Message<?> message, MessageChannel channel) {
                final StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(
                        message, StompHeaderAccessor.class);
                if (accessor == null) {
                    throw new NullPointerException("Accessor is null");
                }
                if (StompCommand.CONNECT.equals(accessor.getCommand())) {
                    final String token = getTokenFromHeaders(accessor.toNativeHeaderMap());
                    final UserDetails user = userService.getByToken(token);
                    final UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
                            user, null, user.getAuthorities());
                    accessor.setUser(auth);
                }
                return message;
            }
        });
    }

    @Order(Ordered.HIGHEST_PRECEDENCE)
    @Bean("csrfChannelInterceptor")
    ChannelInterceptor noopCsrfChannelInterceptor() {
        return new ChannelInterceptor() {
        };
    }

    @Bean
    AuthorizationManager<Message<?>> authorizationManager(
            MessageMatcherDelegatingAuthorizationManager.Builder messages) {
        messages
                .nullDestMatcher().authenticated()
                .anyMessage().authenticated();
        return messages.build();
    }
}
