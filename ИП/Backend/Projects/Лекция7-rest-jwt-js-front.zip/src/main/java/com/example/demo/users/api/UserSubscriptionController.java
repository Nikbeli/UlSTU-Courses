package com.example.demo.users.api;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.core.configuration.Constants;
import com.example.demo.core.security.UserPrincipal;
import com.example.demo.subscriptions.api.SubscriptionDto;
import com.example.demo.subscriptions.model.SubscriptionEntity;
import com.example.demo.users.service.UserService;

@RestController
@RequestMapping(Constants.API_URL + "/user/subscription")
public class UserSubscriptionController {
    private final UserService userService;
    private final ModelMapper modelMapper;

    public UserSubscriptionController(UserService userService, ModelMapper modelMapper) {
        this.userService = userService;
        this.modelMapper = modelMapper;
    }

    private SubscriptionDto toSubscriptionDto(SubscriptionEntity entity) {
        return modelMapper.map(entity, SubscriptionDto.class);
    }

    @GetMapping
    public List<SubscriptionDto> getUserSubscriptions(@AuthenticationPrincipal UserPrincipal principal) {
        return userService.getUserSubscriptions(principal.getId()).stream()
                .map(this::toSubscriptionDto)
                .toList();
    }

    @PostMapping
    public List<SubscriptionDto> enableUserSubscriptions(
            @RequestParam(name = "subscriptions", defaultValue = "") List<Long> subscriptionsIds,
            @AuthenticationPrincipal UserPrincipal principal) {
        return userService.enableUserSubscriptions(principal.getId(), subscriptionsIds).stream()
                .map(this::toSubscriptionDto)
                .toList();
    }

    @DeleteMapping
    public List<SubscriptionDto> disableUserSubscriptions(
            @RequestParam(name = "subscriptions", defaultValue = "") List<Long> subscriptionsIds,
            @AuthenticationPrincipal UserPrincipal principal) {
        return userService.disableUserSubscriptions(principal.getId(), subscriptionsIds).stream()
                .map(this::toSubscriptionDto)
                .toList();
    }

    @DeleteMapping("/all")
    public List<SubscriptionDto> deleteAllUserSubscriptions(@AuthenticationPrincipal UserPrincipal principal) {
        return userService.deleteAllUserSubscriptions(principal.getId()).stream()
                .map(this::toSubscriptionDto)
                .toList();
    }
}
