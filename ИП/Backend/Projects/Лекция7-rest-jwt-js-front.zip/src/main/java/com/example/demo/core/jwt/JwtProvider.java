package com.example.demo.core.jwt;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;

@Component
public class JwtProvider {
    private static final Logger log = LoggerFactory.getLogger(JwtProvider.class);

    private static final byte[] HEX_ARRAY = "0123456789ABCDEF".getBytes(StandardCharsets.US_ASCII);
    private static final String ISSUER = "auth0";

    private final Algorithm algorithm;
    private final JWTVerifier verifier;

    public JwtProvider(JwtProperties jwtProperties) {
        final String key = jwtProperties.getKey();
        if (!StringUtils.hasText(key)) {
            log.info("Generate new JWT key");
            try {
                final MessageDigest salt = MessageDigest.getInstance("SHA-256");
                salt.update(UUID.randomUUID().toString().getBytes(StandardCharsets.UTF_8));
                final String hex = bytesToHex(salt.digest());
                log.info("Use generated JWT key for prod \n{}", hex);
                algorithm = Algorithm.HMAC256(hex);
            } catch (NoSuchAlgorithmException e) {
                throw new JwtException(e);
            }
        } else {
            log.info("Use JWT key from config \n{}", key);
            algorithm = Algorithm.HMAC256(key);
        }
        verifier = JWT.require(algorithm)
                .withIssuer(ISSUER)
                .build();
    }

    private static String bytesToHex(byte[] bytes) {
        byte[] hexChars = new byte[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars, StandardCharsets.UTF_8);
    }

    public String generateToken(String login) {
        final Date issueDate = Date.from(LocalDate.now()
                .atStartOfDay(ZoneId.systemDefault())
                .toInstant());
        final Date expireDate = Date.from(LocalDate.now()
                .plusDays(15)
                .atStartOfDay(ZoneId.systemDefault())
                .toInstant());
        return JWT.create()
                .withIssuer(ISSUER)
                .withIssuedAt(issueDate)
                .withExpiresAt(expireDate)
                .withSubject(login)
                .sign(algorithm);
    }

    private DecodedJWT validateToken(String token) {
        try {
            return verifier.verify(token);
        } catch (JWTVerificationException e) {
            throw new JwtException(String.format("Token verification error: %s", e.getMessage()));
        }
    }

    public boolean isTokenValid(String token) {
        if (!StringUtils.hasText(token)) {
            return false;
        }
        try {
            validateToken(token);
            return true;
        } catch (JwtException e) {
            log.error(e.getMessage());
            return false;
        }
    }

    public Optional<String> getLoginFromToken(String token) {
        try {
            return Optional.ofNullable(validateToken(token).getSubject());
        } catch (JwtException e) {
            log.error(e.getMessage());
            return Optional.empty();
        }
    }
}
