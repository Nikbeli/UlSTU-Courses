package com.example.demo.core.configuration;

import java.io.IOException;

import org.springframework.lang.NonNull;
import org.springframework.web.filter.OncePerRequestFilter;

import com.example.demo.ws.configuration.WebSocketConfiguration;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class SpaWebFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain)
            throws ServletException, IOException {
        String path = request.getRequestURI().substring(request.getContextPath().length());
        if (!path.startsWith(Constants.API_URL) &&
                !path.startsWith("/v3/api-docs") &&
                !path.startsWith("/h2-console") &&
                !path.startsWith(Constants.LOGIN_URL) &&
                !path.startsWith(Constants.SIGNUP_URL) &&
                !path.startsWith(WebSocketConfiguration.ENDPOINT) &&
                !path.contains(".") &&
                path.matches("/(.*)")) {
            request.getRequestDispatcher("/index.html").forward(request, response);
            return;
        }

        filterChain.doFilter(request, response);
    }
}
