package com.example.demo.users.model;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import com.example.demo.core.model.BaseEntity;
import com.example.demo.orders.model.OrderEntity;
import com.example.demo.usersubscription.model.UserSubscriptionEntity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;

@Entity
@Table(name = "users")
public class UserEntity extends BaseEntity {
    @Column(nullable = false, unique = true, length = 20)
    private String login;
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    @OrderBy("id ASC")
    private Set<OrderEntity> orders = new HashSet<>();
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("id ASC")
    private Set<UserSubscriptionEntity> userSubscriptions = new HashSet<>();

    public UserEntity() {
    }

    public UserEntity(String login) {
        this.login = login;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public Set<OrderEntity> getOrders() {
        return orders;
    }

    public void addOrder(OrderEntity order) {
        if (order.getUser() != this) {
            order.setUser(this);
        }
        orders.add(order);
    }

    public Set<UserSubscriptionEntity> getUserSubscriptions() {
        return userSubscriptions;
    }

    public void addSubscription(UserSubscriptionEntity userSubscription) {
        if (userSubscription.getUser() != this) {
            userSubscription.setUser(this);
        }
        userSubscriptions.add(userSubscription);
    }

    public void deleteSubscription(UserSubscriptionEntity userSubscription) {
        if (userSubscription.getUser() != this) {
            return;
        }
        userSubscriptions.remove(userSubscription);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, login, orders, userSubscriptions);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        UserEntity other = (UserEntity) obj;
        return Objects.equals(other.getId(), id)
                && Objects.equals(other.getLogin(), login)
                && Objects.equals(other.getOrders(), orders)
                && Objects.equals(other.getUserSubscriptions(), userSubscriptions);
    }
}
