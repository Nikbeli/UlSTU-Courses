package com.example.demo.orders.model;

import java.util.Objects;

import com.example.demo.core.model.BaseEntity;
import com.example.demo.types.model.TypeEntity;
import com.example.demo.users.model.UserEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "orders")
public class OrderEntity extends BaseEntity {
    @ManyToOne
    @JoinColumn(name = "typeId", nullable = false)
    private TypeEntity type;
    @ManyToOne
    @JoinColumn(name = "userId", nullable = false)
    private UserEntity user;
    @Column(nullable = false)
    private Double price;
    @Column(nullable = false)
    private Integer count;

    public OrderEntity() {
    }

    public OrderEntity(TypeEntity type, Double price, Integer count) {
        this.type = type;
        this.price = price;
        this.count = count;
    }

    public TypeEntity getType() {
        return type;
    }

    public void setType(TypeEntity type) {
        this.type = type;
    }

    public UserEntity getUser() {
        return user;
    }

    public void setUser(UserEntity user) {
        this.user = user;
        if (!user.getOrders().contains(this)) {
            user.getOrders().add(this);
        }
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, type, user.getId(), price, count);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        final OrderEntity other = (OrderEntity) obj;
        return Objects.equals(other.getId(), id)
                && Objects.equals(other.getType(), type)
                && Objects.equals(other.getUser().getId(), user.getId())
                && Objects.equals(other.getPrice(), price)
                && Objects.equals(other.getCount(), count);
    }
}
