package com.example.demo.subscriptions.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.subscriptions.model.SubscriptionEntity;

public interface SubscriptionRepository extends CrudRepository<SubscriptionEntity, Long> {
    Optional<SubscriptionEntity> findByNameIgnoreCase(String name);
}
