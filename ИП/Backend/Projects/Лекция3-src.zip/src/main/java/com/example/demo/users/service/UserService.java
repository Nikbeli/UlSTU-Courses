package com.example.demo.users.service;

import java.util.List;
import java.util.Objects;
import java.util.stream.StreamSupport;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.core.error.NotFoundException;
import com.example.demo.subscriptions.model.SubscriptionEntity;
import com.example.demo.subscriptions.service.SubscriptionService;
import com.example.demo.users.model.UserEntity;
import com.example.demo.users.repository.UserRepository;
import com.example.demo.usersubscription.model.UserSubscriptionEntity;

@Service
public class UserService {
    private final UserRepository repository;
    private final SubscriptionService subscriptionService;

    public UserService(
            UserRepository repository,
            SubscriptionService subscriptionService) {
        this.repository = repository;
        this.subscriptionService = subscriptionService;
    }

    private void checkLogin(String login) {
        if (repository.findByLoginIgnoreCase(login).isPresent()) {
            throw new IllegalArgumentException(
                    String.format("User with login %s is already exists", login));
        }
    }

    @Transactional(readOnly = true)
    public List<UserEntity> getAll() {
        return StreamSupport.stream(repository.findAll().spliterator(), false).toList();
    }

    @Transactional(readOnly = true)
    public UserEntity get(long id) {
        return repository.findById(id)
                .orElseThrow(() -> new NotFoundException(UserEntity.class, id));
    }

    @Transactional
    public UserEntity create(UserEntity entity) {
        if (entity == null) {
            throw new IllegalArgumentException("Entity is null");
        }
        checkLogin(entity.getLogin());
        repository.save(entity);
        subscriptionService.getAll().forEach(subscription -> {
            final UserSubscriptionEntity userSubscription = new UserSubscriptionEntity(entity, subscription, true);
            userSubscription.setUser(entity);
            userSubscription.setSubscription(subscription);
        });
        return repository.save(entity);
    }

    @Transactional
    public UserEntity update(long id, UserEntity entity) {
        final UserEntity existsEntity = get(id);
        checkLogin(entity.getLogin());
        existsEntity.setLogin(entity.getLogin());
        repository.save(existsEntity);
        return existsEntity;
    }

    @Transactional
    public UserEntity delete(long id) {
        final UserEntity existsEntity = get(id);
        repository.delete(existsEntity);
        return existsEntity;
    }

    @Transactional(readOnly = true)
    public List<SubscriptionEntity> getUserSubscriptions(long id) {
        return get(id).getUserSubscriptions().stream()
                .filter(UserSubscriptionEntity::isActive)
                .map(UserSubscriptionEntity::getSubscription)
                .toList();
    }

    private List<SubscriptionEntity> changeUserSubscriptionsState(
            UserEntity existsUser,
            List<Long> subscriptionsIds,
            boolean state) {
        return existsUser.getUserSubscriptions().stream()
                .filter(subscription -> Objects.nonNull(subscription.getSubscription()))
                .filter(subscription -> subscriptionsIds.contains(subscription.getSubscription().getId()))
                .filter(subscription -> subscription.isActive() == !state)
                .map(subscription -> {
                    subscription.setActive(state);
                    return subscription.getSubscription();
                })
                .toList();
    }

    @Transactional
    public List<SubscriptionEntity> enableUserSubscriptions(long id, List<Long> subscriptionsIds) {
        final UserEntity existsUser = get(id);
        final List<SubscriptionEntity> changedSubscriptions = changeUserSubscriptionsState(
                existsUser, subscriptionsIds, true);
        repository.save(existsUser);
        return changedSubscriptions;
    }

    @Transactional
    public List<SubscriptionEntity> disableUserSubscriptions(long id, List<Long> subscriptionsIds) {
        final UserEntity existsUser = get(id);
        final List<SubscriptionEntity> changedSubscriptions = changeUserSubscriptionsState(
                existsUser, subscriptionsIds, false);
        repository.save(existsUser);
        return changedSubscriptions;
    }

    @Transactional
    public List<SubscriptionEntity> deleteAllUserSubscriptions(long id) {
        final UserEntity existsUser = get(id);
        final List<UserSubscriptionEntity> subscriptions = existsUser.getUserSubscriptions().stream()
                .filter(subscription -> Objects.nonNull(subscription.getSubscription()))
                .toList();
        subscriptions.forEach(existsUser::deleteSubscription);
        repository.save(existsUser);
        return subscriptions.stream()
                .map(UserSubscriptionEntity::getSubscription)
                .toList();
    }
}
