package com.example.demo.orders.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.orders.model.OrderEntity;
import com.example.demo.orders.model.OrderGrouped;

public interface OrderRepository extends CrudRepository<OrderEntity, Long> {
    Optional<OrderEntity> findOneByUserIdAndId(long userId, long id);

    List<OrderEntity> findByUserId(long userId);

    List<OrderEntity> findByUserIdAndTypeId(long userId, long typeId);

    // select
    // tpe.name,
    // coalesce(sum(order.price), 0),
    // coalesce(sum(order.count), 0)
    // from types as tpe
    // left join orders as order on tpe.id = order.type_id and order.user_id = ?
    // group by tpe.name order by tpe.id
    @Query("select "
            + "t as type, "
            + "coalesce(sum(o.price), 0) as totalPrice, "
            + "coalesce(sum(o.count), 0) as totalCount "
            + "from TypeEntity t left join OrderEntity o on o.type = t and o.user.id = ?1 "
            + "group by t order by t.id")
    List<OrderGrouped> getOrdersTotalByType(long userId);
}
