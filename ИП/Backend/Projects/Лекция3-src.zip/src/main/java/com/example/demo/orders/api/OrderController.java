package com.example.demo.orders.api;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.core.configuration.Constants;
import com.example.demo.orders.model.OrderEntity;
import com.example.demo.orders.model.OrderGrouped;
import com.example.demo.orders.service.OrderService;
import com.example.demo.types.service.TypeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping(Constants.API_URL + "/user/{user}/order")
public class OrderController {
    private final OrderService orderService;
    private final TypeService typeService;
    private final ModelMapper modelMapper;

    public OrderController(OrderService orderService, TypeService typeService, ModelMapper modelMapper) {
        this.orderService = orderService;
        this.typeService = typeService;
        this.modelMapper = modelMapper;
    }

    private OrderDto toDto(OrderEntity entity) {
        return modelMapper.map(entity, OrderDto.class);
    }

    private OrderEntity toEntity(OrderDto dto) {
        final OrderEntity entity = modelMapper.map(dto, OrderEntity.class);
        entity.setType(typeService.get(dto.getTypeId()));
        return entity;
    }

    private OrderGroupedDto toGroupedDto(OrderGrouped entity) {
        return modelMapper.map(entity, OrderGroupedDto.class);
    }

    @GetMapping
    public List<OrderDto> getAll(
            @PathVariable(name = "user") Long userId,
            @RequestParam(name = "typeId", defaultValue = "0") Long typeId) {
        return orderService.getAll(userId, typeId).stream()
                .map(this::toDto)
                .toList();
    }

    @GetMapping("/{id}")
    public OrderDto get(
            @PathVariable(name = "user") Long userId,
            @PathVariable(name = "id") Long id) {
        return toDto(orderService.get(userId, id));
    }

    @PostMapping
    public OrderDto create(
            @PathVariable(name = "user") Long userId,
            @RequestBody @Valid OrderDto dto) {
        return toDto(orderService.create(userId, toEntity(dto)));
    }

    @PutMapping("/{id}")
    public OrderDto update(
            @PathVariable(name = "user") Long userId,
            @PathVariable(name = "id") Long id,
            @RequestBody @Valid OrderDto dto) {
        return toDto(orderService.update(userId, id, toEntity(dto)));
    }

    @DeleteMapping("/{id}")
    public OrderDto delete(
            @PathVariable(name = "user") Long userId,
            @PathVariable(name = "id") Long id) {
        return toDto(orderService.delete(userId, id));
    }

    @GetMapping("/total")
    public List<OrderGroupedDto> getMethodName(@PathVariable(name = "user") Long userId) {
        return orderService.getTotal(userId).stream()
                .map(this::toGroupedDto)
                .toList();
    }

}
