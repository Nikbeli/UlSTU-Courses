package com.example.demo.users.service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.example.demo.core.configuration.Constants;
import com.example.demo.core.error.NotFoundException;
import com.example.demo.core.security.UserPrincipal;
import com.example.demo.subscriptions.model.SubscriptionEntity;
import com.example.demo.subscriptions.service.SubscriptionService;
import com.example.demo.users.model.UserEntity;
import com.example.demo.users.model.UserRole;
import com.example.demo.users.model.UserSubscriptionWithStatus;
import com.example.demo.users.repository.UserRepository;
import com.example.demo.usersubscription.model.UserSubscriptionEntity;

@Service
public class UserService implements UserDetailsService {
    private final UserRepository repository;
    private final SubscriptionService subscriptionService;
    private final PasswordEncoder passwordEncoder;

    public UserService(
            UserRepository repository,
            SubscriptionService subscriptionService,
            PasswordEncoder passwordEncoder) {
        this.repository = repository;
        this.subscriptionService = subscriptionService;
        this.passwordEncoder = passwordEncoder;
    }

    private void checkLogin(Long id, String login) {
        final Optional<UserEntity> existsUser = repository.findByLoginIgnoreCase(login);
        if (existsUser.isPresent() && !existsUser.get().getId().equals(id)) {
            throw new IllegalArgumentException(
                    String.format("User with login %s is already exists", login));
        }
    }

    @Transactional(readOnly = true)
    public List<UserEntity> getAll() {
        return StreamSupport.stream(repository.findAll().spliterator(), false).toList();
    }

    @Transactional(readOnly = true)
    public Page<UserEntity> getAll(int page, int size) {
        return repository.findAll(PageRequest.of(page, size, Sort.by("id")));
    }

    @Transactional(readOnly = true)
    public UserEntity get(long id) {
        return repository.findById(id)
                .orElseThrow(() -> new NotFoundException(UserEntity.class, id));
    }

    @Transactional(readOnly = true)
    public UserEntity getByLogin(String login) {
        return repository.findByLoginIgnoreCase(login)
                .orElseThrow(() -> new IllegalArgumentException("Invalid login"));
    }

    @Transactional
    public UserEntity create(UserEntity entity) {
        if (entity == null) {
            throw new IllegalArgumentException("Entity is null");
        }
        checkLogin(null, entity.getLogin());
        final String password = Optional.ofNullable(entity.getPassword()).orElse("");
        entity.setPassword(
                passwordEncoder.encode(
                        StringUtils.hasText(password.strip()) ? password : Constants.DEFAULT_PASSWORD));
        entity.setRole(Optional.ofNullable(entity.getRole()).orElse(UserRole.USER));
        repository.save(entity);
        subscriptionService.getAll().forEach(subscription -> {
            final UserSubscriptionEntity userSubscription = new UserSubscriptionEntity(entity, subscription, true);
            userSubscription.setUser(entity);
            userSubscription.setSubscription(subscription);
        });
        return repository.save(entity);
    }

    @Transactional
    public UserEntity update(long id, UserEntity entity) {
        final UserEntity existsEntity = get(id);
        checkLogin(id, entity.getLogin());
        existsEntity.setLogin(entity.getLogin());
        repository.save(existsEntity);
        return existsEntity;
    }

    @Transactional
    public UserEntity delete(long id) {
        final UserEntity existsEntity = get(id);
        repository.delete(existsEntity);
        return existsEntity;
    }

    private Map<Long, UserSubscriptionEntity> getUserSubscriptionsMap(Set<UserSubscriptionEntity> subscriptions) {
        return Optional.ofNullable(subscriptions).orElse(Collections.emptySet()).stream()
                .collect(Collectors.toMap(item -> item.getSubscription().getId(), Function.identity()));
    }

    @Transactional(readOnly = true)
    public List<UserSubscriptionWithStatus> getUserSubscriptions(long id) {
        final Map<Long, UserSubscriptionEntity> userSubscriptions = getUserSubscriptionsMap(
                get(id).getUserSubscriptions());
        return subscriptionService.getAll().stream()
                .map(item -> {
                    final boolean active = Optional.ofNullable(userSubscriptions.get(item.getId()))
                            .map(UserSubscriptionEntity::isActive)
                            .orElse(false);
                    return new UserSubscriptionWithStatus(item, active);
                })
                .toList();
    }

    @Transactional
    public void saveUserSubscriptions(long id, Set<UserSubscriptionWithStatus> subscriptions) {
        final UserEntity existsUser = get(id);
        final Map<Long, SubscriptionEntity> existsSubscriptions = subscriptionService.getAll().stream()
                .collect(Collectors.toMap(SubscriptionEntity::getId, Function.identity()));
        final Map<Long, UserSubscriptionEntity> userSubscriptions = getUserSubscriptionsMap(
                existsUser.getUserSubscriptions());
        subscriptions.stream()
                .filter(item -> existsSubscriptions.keySet().contains(item.getId()))
                .forEach(item -> {
                    userSubscriptions.computeIfAbsent(item.getId(), key -> {
                        final UserSubscriptionEntity subscription = new UserSubscriptionEntity(
                                existsUser, existsSubscriptions.get(key), item.isActive());
                        existsUser.addSubscription(subscription);
                        return subscription;
                    });
                    userSubscriptions.computeIfPresent(item.getId(), (key, value) -> {
                        value.setActive(item.isActive());
                        return value;
                    });
                });
        repository.save(existsUser);
    }

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        final UserEntity existsUser = getByLogin(username);
        return new UserPrincipal(existsUser);
    }
}
