package com.example.demo.usersubscription.model;

import java.util.Objects;
import java.util.Optional;

import jakarta.persistence.Embeddable;

@Embeddable
public class UserSubscriptionId {
    private Long userId;
    private Long subscriptionId;

    public UserSubscriptionId() {
    }

    public UserSubscriptionId(Long userId, Long subscriptionId) {
        this.userId = userId;
        this.subscriptionId = subscriptionId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getSubscriptionId() {
        return subscriptionId;
    }

    public void setSubscriptionId(Long subscriptionId) {
        this.subscriptionId = subscriptionId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                Optional.ofNullable(userId).orElse(0L),
                Optional.ofNullable(subscriptionId).orElse(0L));
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        UserSubscriptionId other = (UserSubscriptionId) obj;
        return Objects.equals(userId, other.userId)
                && Objects.equals(subscriptionId, other.subscriptionId);
    }

}
