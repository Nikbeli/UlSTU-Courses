package com.example.demo.subscriptions.api;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.core.configuration.Constants;
import com.example.demo.subscriptions.model.SubscriptionEntity;
import com.example.demo.subscriptions.service.SubscriptionService;

import jakarta.validation.Valid;

@Controller
@RequestMapping(SubscriptionController.URL)
public class SubscriptionController {
    public static final String URL = Constants.ADMIN_PREFIX + "/subscription";
    private static final String SUBSCRIPTION_VIEW = "subscription";
    private static final String SUBSCRIPTION_EDIT_VIEW = "subscription-edit";
    private static final String SUBSCRIPTION_ATTRIBUTE = "subscription";

    private final SubscriptionService subscriptionService;
    private final ModelMapper modelMapper;

    public SubscriptionController(SubscriptionService subscriptionService, ModelMapper modelMapper) {
        this.subscriptionService = subscriptionService;
        this.modelMapper = modelMapper;
    }

    private SubscriptionDto toDto(SubscriptionEntity entity) {
        return modelMapper.map(entity, SubscriptionDto.class);
    }

    private SubscriptionEntity toEntity(SubscriptionDto dto) {
        return modelMapper.map(dto, SubscriptionEntity.class);
    }

    @GetMapping
    public String getAll(Model model) {
        model.addAttribute(
                "items",
                subscriptionService.getAll().stream()
                        .map(this::toDto)
                        .toList());
        return SUBSCRIPTION_VIEW;
    }

    @GetMapping("/edit/")
    public String create(Model model) {
        model.addAttribute(SUBSCRIPTION_ATTRIBUTE, new SubscriptionDto());
        return SUBSCRIPTION_EDIT_VIEW;
    }

    @PostMapping("/edit/")
    public String create(
            @ModelAttribute(name = SUBSCRIPTION_ATTRIBUTE) @Valid SubscriptionDto subscription,
            BindingResult bindingResult,
            Model model) {
        if (bindingResult.hasErrors()) {
            return SUBSCRIPTION_EDIT_VIEW;
        }
        subscriptionService.create(toEntity(subscription));
        return Constants.REDIRECT_VIEW + URL;
    }

    @GetMapping("/edit/{id}")
    public String update(
            @PathVariable(name = "id") Long id,
            Model model) {
        if (id <= 0) {
            throw new IllegalArgumentException();
        }
        model.addAttribute(SUBSCRIPTION_ATTRIBUTE, toDto(subscriptionService.get(id)));
        return SUBSCRIPTION_EDIT_VIEW;
    }

    @PostMapping("/edit/{id}")
    public String update(
            @PathVariable(name = "id") Long id,
            @ModelAttribute(name = SUBSCRIPTION_ATTRIBUTE) @Valid SubscriptionDto subscription,
            BindingResult bindingResult,
            Model model) {
        if (bindingResult.hasErrors()) {
            return SUBSCRIPTION_EDIT_VIEW;
        }
        if (id <= 0) {
            throw new IllegalArgumentException();
        }
        subscriptionService.update(id, toEntity(subscription));
        return Constants.REDIRECT_VIEW + URL;
    }

    @PostMapping("/delete/{id}")
    public String delete(
            @PathVariable(name = "id") Long id) {
        subscriptionService.delete(id);
        return Constants.REDIRECT_VIEW + URL;
    }
}
