package com.example.demo.users.api;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.example.demo.core.configuration.Constants;
import com.example.demo.core.security.UserPrincipal;
import com.example.demo.core.session.SessionCart;
import com.example.demo.orders.model.OrderEntity;
import com.example.demo.orders.service.OrderService;
import com.example.demo.types.api.TypeDto;
import com.example.demo.types.model.TypeEntity;
import com.example.demo.types.service.TypeService;

import jakarta.validation.Valid;

@Controller
@RequestMapping(UserCartController.URL)
@SessionAttributes("types")
public class UserCartController {
    public static final String URL = "/cart";
    private static final String ORDER_VIEW = "cart";
    private static final String ORDER_ATTRIBUTE = "order";
    private static final String CART_ATTRIBUTE = "cart";

    private final TypeService typeService;
    private final OrderService orderService;
    private final SessionCart cart;
    private final ModelMapper modelMapper;

    public UserCartController(
            TypeService typeService,
            OrderService orderService,
            SessionCart cart,
            ModelMapper modelMapper) {
        this.typeService = typeService;
        this.orderService = orderService;
        this.cart = cart;
        this.modelMapper = modelMapper;
    }

    private TypeDto toTypeDto(TypeEntity entity) {
        return modelMapper.map(entity, TypeDto.class);
    }

    private List<OrderEntity> toOrderEntities(Collection<UserCartDto> dtos) {
        final Set<Long> typeIds = dtos.stream()
                .map(UserCartDto::getType)
                .collect(Collectors.toSet());
        final Map<Long, TypeEntity> types = typeService.getByIds(typeIds).stream()
                .collect(Collectors.toMap(TypeEntity::getId, Function.identity()));
        return dtos.stream()
                .map(dto -> {
                    final OrderEntity entity = modelMapper.map(dto, OrderEntity.class);
                    entity.setType(types.get(dto.getType()));
                    return entity;
                })
                .toList();
    }

    @GetMapping
    public String getCart(Model model) {
        model.addAttribute("types",
                typeService.getAll().stream()
                        .map(this::toTypeDto)
                        .toList());
        model.addAttribute(ORDER_ATTRIBUTE, new UserCartDto());
        model.addAttribute(CART_ATTRIBUTE, cart.values());
        return ORDER_VIEW;
    }

    @PostMapping
    public String addOrderToCart(
            @ModelAttribute(name = ORDER_ATTRIBUTE) @Valid UserCartDto order,
            BindingResult bindingResult,
            SessionStatus status,
            Model model) {
        if (bindingResult.hasErrors()) {
            return ORDER_VIEW;
        }
        status.setComplete();
        order.setTypeName(typeService.get(order.getType()).getName());
        cart.computeIfPresent(order.hashCode(), (key, value) -> {
            value.setCount(value.getCount() + order.getCount());
            return value;
        });
        cart.putIfAbsent(order.hashCode(), order);
        return Constants.REDIRECT_VIEW + URL;
    }

    @PostMapping("/save")
    public String saveCart(
            Model model,
            @AuthenticationPrincipal UserPrincipal principal) {
        orderService.createAll(principal.getId(), toOrderEntities(cart.values()));
        cart.clear();
        return Constants.REDIRECT_VIEW + URL;
    }

    @PostMapping("/clear")
    public String clearCart() {
        cart.clear();
        return Constants.REDIRECT_VIEW + URL;
    }

    @PostMapping("/increase")
    public String increaseCartCount(
            @RequestParam(name = "type") Long type,
            @RequestParam(name = "price") Double price) {
        cart.computeIfPresent(Objects.hash(type, price), (key, value) -> {
            value.setCount(value.getCount() + 1);
            return value;
        });
        return Constants.REDIRECT_VIEW + URL;
    }

    @PostMapping("/decrease")
    public String decreaseCartCount(
            @RequestParam(name = "type") Long type,
            @RequestParam(name = "price") Double price) {
        cart.computeIfPresent(Objects.hash(type, price), (key, value) -> {
            value.setCount(value.getCount() - 1);
            return value;
        });
        final Map<Integer, UserCartDto> filteredCart = cart.entrySet()
                .stream()
                .filter(item -> item.getValue().getCount() > 0)
                .collect(Collectors.toMap(Entry::getKey, Entry::getValue));
        cart.clear();
        cart.putAll(filteredCart);
        return Constants.REDIRECT_VIEW + URL;
    }
}
