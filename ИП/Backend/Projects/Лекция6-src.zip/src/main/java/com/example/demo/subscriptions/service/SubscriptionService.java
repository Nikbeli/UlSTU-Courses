package com.example.demo.subscriptions.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.StreamSupport;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.core.error.NotFoundException;
import com.example.demo.subscriptions.model.SubscriptionEntity;
import com.example.demo.subscriptions.repository.SubscriptionRepository;

@Service
public class SubscriptionService {
    private final SubscriptionRepository repository;

    public SubscriptionService(SubscriptionRepository repository) {
        this.repository = repository;
    }

    private void checkName(Long id, String name) {
        final Optional<SubscriptionEntity> existsType = repository.findByNameIgnoreCase(name);
        if (existsType.isPresent() && !existsType.get().getId().equals(id)) {
            throw new IllegalArgumentException(
                    String.format("Subscription with name %s is already exists", name));
        }
    }

    @Transactional(readOnly = true)
    public List<SubscriptionEntity> getAll() {
        return StreamSupport.stream(repository.findAll(Sort.by("id")).spliterator(), false).toList();
    }

    @Transactional(readOnly = true)
    public SubscriptionEntity get(long id) {
        return repository.findById(id)
                .orElseThrow(() -> new NotFoundException(SubscriptionEntity.class, id));
    }

    @Transactional
    public SubscriptionEntity create(SubscriptionEntity entity) {
        if (entity == null) {
            throw new IllegalArgumentException("Entity is null");
        }
        checkName(null, entity.getName());
        return repository.save(entity);
    }

    @Transactional
    public SubscriptionEntity update(Long id, SubscriptionEntity entity) {
        final SubscriptionEntity existsEntity = get(id);
        checkName(id, entity.getName());
        existsEntity.setName(entity.getName());
        return repository.save(existsEntity);
    }

    @Transactional
    public SubscriptionEntity delete(Long id) {
        final SubscriptionEntity existsEntity = get(id);
        repository.delete(existsEntity);
        return existsEntity;
    }

}
