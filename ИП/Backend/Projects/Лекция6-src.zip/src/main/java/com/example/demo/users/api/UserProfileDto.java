package com.example.demo.users.api;

import java.util.ArrayList;
import java.util.List;

public class UserProfileDto {
    private List<UserSubscriptionDto> subscriptions = new ArrayList<>();

    public UserProfileDto() {
    }

    public UserProfileDto(List<UserSubscriptionDto> subscriptions) {
        this.subscriptions = subscriptions;
    }

    public List<UserSubscriptionDto> getSubscriptions() {
        return subscriptions;
    }

    public void setSubscriptions(List<UserSubscriptionDto> subscriptions) {
        this.subscriptions = subscriptions;
    }
}
