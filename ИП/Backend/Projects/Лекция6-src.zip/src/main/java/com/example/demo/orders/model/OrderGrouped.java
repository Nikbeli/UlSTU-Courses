package com.example.demo.orders.model;

import com.example.demo.types.model.TypeEntity;

public interface OrderGrouped {
    TypeEntity getType();

    double getTotalPrice();

    int getTotalCount();
}
