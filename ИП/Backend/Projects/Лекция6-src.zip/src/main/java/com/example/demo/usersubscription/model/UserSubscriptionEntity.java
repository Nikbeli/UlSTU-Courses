package com.example.demo.usersubscription.model;

import java.util.Objects;

import com.example.demo.subscriptions.model.SubscriptionEntity;
import com.example.demo.users.model.UserEntity;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;

@Entity
@Table(name = "users_subscriptions")
public class UserSubscriptionEntity {
    @EmbeddedId
    private UserSubscriptionId id = new UserSubscriptionId();
    @ManyToOne
    @MapsId("userId")
    @JoinColumn(name = "user_id")
    private UserEntity user;
    @ManyToOne
    @MapsId("subscriptionId")
    @JoinColumn(name = "subscription_id")
    private SubscriptionEntity subscription;
    private boolean active;

    public UserSubscriptionEntity() {
    }

    public UserSubscriptionEntity(UserEntity user, SubscriptionEntity subscription, boolean active) {
        this.user = user;
        this.subscription = subscription;
        this.active = active;
    }

    public UserSubscriptionId getId() {
        return id;
    }

    public void setId(UserSubscriptionId id) {
        this.id = id;
    }

    public UserEntity getUser() {
        return user;
    }

    public void setUser(UserEntity user) {
        this.user = user;
        if (!user.getUserSubscriptions().contains(this)) {
            user.getUserSubscriptions().add(this);
        }
    }

    public SubscriptionEntity getSubscription() {
        return subscription;
    }

    public void setSubscription(SubscriptionEntity subscription) {
        this.subscription = subscription;
        if (!subscription.getUserSubscriptions().contains(this)) {
            subscription.getUserSubscriptions().add(this);
        }
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, user.getId(), subscription.getId(), active);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        UserSubscriptionEntity other = (UserSubscriptionEntity) obj;
        return Objects.equals(id, other.id)
                && Objects.equals(user.getId(), other.user.getId())
                && Objects.equals(subscription.getId(), other.subscription.getId())
                && active == other.active;
    }

}
