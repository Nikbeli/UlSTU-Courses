package com.example.demo.users.api;

import java.util.Objects;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class UserCartDto {
    @NotNull
    private Long type;
    private String typeName;
    @NotNull
    @Min(1000)
    private Double price;
    @NotNull
    @Min(1)
    private Integer count;

    public Long getType() {
        return type;
    }

    public void setType(Long typeId) {
        this.type = typeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, price);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        UserCartDto other = (UserCartDto) obj;
        return Objects.equals(type, other.type) && Objects.equals(price, other.price);
    }
}
