package com.example.demo.core.session;

import java.util.HashMap;

import com.example.demo.users.api.UserCartDto;

public class SessionCart extends HashMap<Integer, UserCartDto> {
    public double getSum() {
        return this.values().stream()
                .map(item -> item.getCount() * item.getPrice())
                .mapToDouble(Double::doubleValue)
                .sum();
    }
}
