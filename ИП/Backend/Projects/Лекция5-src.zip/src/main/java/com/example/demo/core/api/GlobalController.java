package com.example.demo.core.api;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.example.demo.core.configuration.Constants;
import com.example.demo.core.session.SessionCart;
import com.example.demo.users.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@ControllerAdvice
public class GlobalController {
    private final UserService userService;
    private final SessionCart cart;

    public GlobalController(
            UserService userService,
            SessionCart cart) {
        this.userService = userService;
        this.cart = cart;
    }

    @ModelAttribute("servletPath")
    String getRequestServletPath(HttpServletRequest request) {
        return request.getServletPath();
    }

    @ModelAttribute("totalCart")
    double getTotalCart(HttpSession session) {
        return cart.getSum();
    }

    @ModelAttribute("userName")
    String getUserName(@CookieValue(value = Constants.USER_COOKIE, defaultValue = "0") long userId) {
        if (userId <= 0) {
            return "";
        }
        return userService.get(userId).getLogin();
    }
}
