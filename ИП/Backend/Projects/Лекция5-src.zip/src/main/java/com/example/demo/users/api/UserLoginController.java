package com.example.demo.users.api;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.core.configuration.Constants;
import com.example.demo.users.model.UserEntity;
import com.example.demo.users.service.UserService;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@Controller
public class UserLoginController {
    public static final String LOGIN_URL = "/login";

    private static final String LOGIN_VIEW = "login";
    private static final String USER_ATTRIBUTE = "user";

    private final UserService userService;

    public UserLoginController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping(LOGIN_URL)
    public String login(Model model) {
        model.addAttribute(USER_ATTRIBUTE, new UserLoginDto());
        return LOGIN_VIEW;
    }

    @PostMapping(LOGIN_URL)
    // Порядок аргументов важен!
    public String login(
            HttpServletResponse response,
            @ModelAttribute(name = USER_ATTRIBUTE) @Valid UserLoginDto user,
            BindingResult bindingResult,
            Model model) {
        if (bindingResult.hasErrors()) {
            return LOGIN_VIEW;
        }
        final UserEntity existsUser = userService.getByLogin(user.getLogin());
        final Cookie cookie = new Cookie(Constants.USER_COOKIE, existsUser.getId().toString());
        response.addCookie(cookie);
        return Constants.REDIRECT_VIEW + "/";
    }

    @PostMapping("/logout")
    public String logout(HttpServletResponse response) {
        final Cookie cookie = new Cookie(Constants.USER_COOKIE, "0");
        response.addCookie(cookie);
        return Constants.REDIRECT_VIEW + "/";
    }
}
