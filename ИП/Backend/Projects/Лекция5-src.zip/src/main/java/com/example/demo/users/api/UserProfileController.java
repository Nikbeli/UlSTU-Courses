package com.example.demo.users.api;

import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.core.api.PageAttributesMapper;
import com.example.demo.core.configuration.Constants;
import com.example.demo.orders.api.OrderDto;
import com.example.demo.orders.api.OrderGroupedDto;
import com.example.demo.orders.model.OrderEntity;
import com.example.demo.orders.model.OrderGrouped;
import com.example.demo.orders.service.OrderService;
import com.example.demo.types.api.TypeDto;
import com.example.demo.types.model.TypeEntity;
import com.example.demo.types.service.TypeService;
import com.example.demo.users.model.UserSubscriptionWithStatus;
import com.example.demo.users.service.UserService;

import jakarta.validation.Valid;

@Controller
public class UserProfileController {
    private static final String PROFILE_VIEW = "profile";

    private static final String PAGE_ATTRIBUTE = "page";
    private static final String TYPEID_ATTRIBUTE = "typeId";
    private static final String PROFILE_ATTRIBUTE = "profile";

    private final OrderService orderService;
    private final TypeService typeService;
    private final UserService userService;
    private final ModelMapper modelMapper;

    public UserProfileController(
            OrderService orderService,
            TypeService typeService,
            UserService userService,
            ModelMapper modelMapper) {
        this.orderService = orderService;
        this.typeService = typeService;
        this.userService = userService;
        this.modelMapper = modelMapper;
    }

    private OrderDto toDto(OrderEntity entity) {
        return modelMapper.map(entity, OrderDto.class);
    }

    private OrderGroupedDto toGroupedDto(OrderGrouped entity) {
        return modelMapper.map(entity, OrderGroupedDto.class);
    }

    private TypeDto toTypeDto(TypeEntity entity) {
        return modelMapper.map(entity, TypeDto.class);
    }

    private UserSubscriptionDto tSubscriptionDto(UserSubscriptionWithStatus entity) {
        return modelMapper.map(entity, UserSubscriptionDto.class);
    }

    private UserSubscriptionWithStatus toSubscriptionWithStatus(UserSubscriptionDto dto) {
        return modelMapper.map(dto, UserSubscriptionWithStatus.class);
    }

    @GetMapping
    public String getProfile(
            @CookieValue(value = Constants.USER_COOKIE, defaultValue = "0") long userId,
            @RequestParam(name = PAGE_ATTRIBUTE, defaultValue = "0") int page,
            @RequestParam(name = TYPEID_ATTRIBUTE, defaultValue = "0") int typeId,
            Model model) {
        if (userId <= 0) {
            return Constants.REDIRECT_VIEW + UserLoginController.LOGIN_URL;
        }
        model.addAttribute(PAGE_ATTRIBUTE, page);
        model.addAttribute(TYPEID_ATTRIBUTE, typeId);
        model.addAllAttributes(PageAttributesMapper.toAttributes(
                orderService.getAll(userId, typeId, page, Constants.DEFUALT_PAGE_SIZE),
                this::toDto));
        model.addAttribute("stats",
                orderService.getTotal(userId).stream()
                        .map(this::toGroupedDto)
                        .toList());
        model.addAttribute("types",
                typeService.getAll().stream()
                        .map(this::toTypeDto)
                        .toList());
        model.addAttribute(PROFILE_ATTRIBUTE,
                new UserProfileDto(userService.getUserSubscriptions(userId).stream()
                        .map(this::tSubscriptionDto)
                        .toList()));
        return PROFILE_VIEW;
    }

    @PostMapping
    public String saveProfile(
            @CookieValue(value = Constants.USER_COOKIE, defaultValue = "0") long userId,
            @ModelAttribute(name = PROFILE_ATTRIBUTE) @Valid UserProfileDto profile,
            BindingResult bindResult,
            Model model) {
        if (bindResult.hasErrors()) {
            return PROFILE_VIEW;
        }
        userService.saveUserSubscriptions(userId,
                profile.getSubscriptions().stream()
                        .map(this::toSubscriptionWithStatus)
                        .collect(Collectors.toSet()));
        return Constants.REDIRECT_VIEW + "/";
    }

    @PostMapping("/delete/{id}")
    public String deleteOrder(
            @CookieValue(value = Constants.USER_COOKIE, defaultValue = "0") long userId,
            @PathVariable(name = "id") Long id,
            @RequestParam(name = PAGE_ATTRIBUTE, defaultValue = "0") int page,
            @RequestParam(name = TYPEID_ATTRIBUTE, defaultValue = "0") int typeId,
            RedirectAttributes redirectAttributes) {
        redirectAttributes.addAttribute(PAGE_ATTRIBUTE, page);
        redirectAttributes.addAttribute(TYPEID_ATTRIBUTE, typeId);
        orderService.delete(userId, id);
        return Constants.REDIRECT_VIEW + "/";
    }
}
