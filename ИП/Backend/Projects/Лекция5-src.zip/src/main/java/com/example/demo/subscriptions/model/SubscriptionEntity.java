package com.example.demo.subscriptions.model;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import com.example.demo.core.model.BaseEntity;
import com.example.demo.usersubscription.model.UserSubscriptionEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;

@Entity
@Table(name = "subscriptions")
public class SubscriptionEntity extends BaseEntity {
    @Column(nullable = false, unique = true, length = 50)
    private String name;
    @OneToMany(mappedBy = "subscription")
    @OrderBy("id ASC")
    private Set<UserSubscriptionEntity> userSubscriptions = new HashSet<>();

    public SubscriptionEntity() {
    }

    public SubscriptionEntity(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<UserSubscriptionEntity> getUserSubscriptions() {
        return userSubscriptions;
    }

    public void addUser(UserSubscriptionEntity userSubscription) {
        if (userSubscription.getSubscription() != this) {
            userSubscription.setSubscription(this);
        }
        userSubscriptions.add(userSubscription);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, userSubscriptions);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        SubscriptionEntity other = (SubscriptionEntity) obj;
        return Objects.equals(id, other.id)
                && Objects.equals(name, other.name)
                && Objects.equals(userSubscriptions, other.userSubscriptions);
    }
}
