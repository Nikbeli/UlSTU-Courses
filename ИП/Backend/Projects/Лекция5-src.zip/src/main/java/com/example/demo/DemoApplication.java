package com.example.demo;

import java.util.List;
import java.util.Objects;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.orders.model.OrderEntity;
import com.example.demo.orders.service.OrderService;
import com.example.demo.subscriptions.model.SubscriptionEntity;
import com.example.demo.subscriptions.service.SubscriptionService;
import com.example.demo.types.model.TypeEntity;
import com.example.demo.types.service.TypeService;
import com.example.demo.users.model.UserEntity;
import com.example.demo.users.service.UserService;

@SpringBootApplication
public class DemoApplication implements CommandLineRunner {
    private final Logger log = LoggerFactory.getLogger(DemoApplication.class);

    private final TypeService typeService;
    private final SubscriptionService subscriptionService;
    private final UserService userService;
    private final OrderService orderService;

    public DemoApplication(
            TypeService typeService,
            SubscriptionService subscriptionService,
            UserService userService,
            OrderService orderService) {
        this.typeService = typeService;
        this.subscriptionService = subscriptionService;
        this.userService = userService;
        this.orderService = orderService;
    }

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        if (args.length > 0 && Objects.equals("--populate", args[0])) {
            log.info("Create default type values");
            final var type1 = typeService.create(new TypeEntity("Ноутбук"));
            final var type2 = typeService.create(new TypeEntity("Телефон"));
            final var type3 = typeService.create(new TypeEntity("Игровая приставка"));

            log.info("Create default subscription values");
            subscriptionService.create(new SubscriptionEntity("Подписка 1"));
            subscriptionService.create(new SubscriptionEntity("Подписка 2"));
            subscriptionService.create(new SubscriptionEntity("Подписка 3"));

            log.info("Create default user values");
            final var user1 = userService.create(new UserEntity("user1"));

            IntStream.range(2, 27)
                    .forEach(value -> userService.create(
                            new UserEntity("user".concat(String.valueOf(value)))));

            log.info("Create default order values");
            final var orders = List.of(
                    new OrderEntity(type1, 49999.00, 20),
                    new OrderEntity(type1, 129999.00, 3),
                    new OrderEntity(type2, 15450.50, 30),
                    new OrderEntity(type2, 69900.50, 10),
                    new OrderEntity(type2, 150000.00, 6),
                    new OrderEntity(type3, 75000.00, 6),
                    new OrderEntity(type3, 67800.00, 3));
            orders.forEach(order -> orderService.create(user1.getId(), order));
        }
    }
}
