H2 Console: \
http://localhost:8080/h2-console

JDBC URL: jdbc:h2:file:./data \
User Name: sa \
Password: password

Почитать:

- Security with Spring  https://www.baeldung.com/security-spring
- Spring Security https://docs.spring.io/spring-security/reference/index.html
