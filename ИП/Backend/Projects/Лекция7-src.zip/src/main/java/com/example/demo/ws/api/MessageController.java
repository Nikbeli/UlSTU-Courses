package com.example.demo.ws.api;

import java.security.Principal;

import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.ws.configuration.WebSocketConfiguration;
import com.example.demo.ws.service.MessageService;

@Controller
public class MessageController {
    public static final String URL = "/messages";
    public static final String MESSAGES_TOPIC = WebSocketConfiguration.TOPIC_PREFIX + URL;

    private final MessageService messageService;

    public MessageController(MessageService messageService) {
        this.messageService = messageService;
    }

    @GetMapping("/whoami")
    @ResponseBody
    public String getUserName(Principal principal) {
        return principal.getName();
    }

    @MessageMapping(URL)
    public void sendMessageToAll(String message, Principal author) {
        messageService.sendMessageToAll(MESSAGES_TOPIC, new MessageDto(author.getName(), message));
    }

    @MessageMapping(URL + "/{user}")
    public void sendMessageToUser(@DestinationVariable String user, String message, Principal author) {
        messageService.sendMessageToUser(MESSAGES_TOPIC, user, new MessageDto(author.getName(), message));
    }
}
