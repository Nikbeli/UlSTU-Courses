package com.example.demo.orders.service;

import java.util.List;
import java.util.stream.StreamSupport;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.core.error.NotFoundException;
import com.example.demo.orders.model.OrderEntity;
import com.example.demo.orders.model.OrderGrouped;
import com.example.demo.orders.repository.OrderRepository;
import com.example.demo.users.model.UserEntity;
import com.example.demo.users.service.UserService;

@Service
public class OrderService {
    private final OrderRepository repository;
    private final UserService userService;

    public OrderService(OrderRepository repository, UserService userService) {
        this.repository = repository;
        this.userService = userService;
    }

    @Transactional(readOnly = true)
    public List<OrderEntity> getAll(long userId, long typeId) {
        userService.get(userId);
        if (typeId <= 0L) {
            return repository.findByUserId(userId);
        } else {
            return repository.findByUserIdAndTypeId(userId, typeId);
        }
    }

    @Transactional(readOnly = true)
    public Page<OrderEntity> getAll(long userId, long typeId, int page, int size) {
        final Pageable pageable = PageRequest.of(page, size, Sort.by("id"));
        userService.get(userId);
        if (typeId <= 0L) {
            return repository.findByUserId(userId, pageable);
        } else {
            return repository.findByUserIdAndTypeId(userId, typeId, pageable);
        }
    }

    @Transactional(readOnly = true)
    public OrderEntity get(long userId, long id) {
        userService.get(userId);
        return repository.findOneByUserIdAndId(userId, id)
                .orElseThrow(() -> new NotFoundException(OrderEntity.class, id));
    }

    @Transactional
    public OrderEntity create(long userId, OrderEntity entity) {
        if (entity == null) {
            throw new IllegalArgumentException("Entity is null");
        }
        final UserEntity existsUser = userService.get(userId);
        entity.setUser(existsUser);
        return repository.save(entity);
    }

    @Transactional
    public List<OrderEntity> createAll(long userId, List<OrderEntity> entities) {
        if (entities == null || entities.isEmpty()) {
            throw new IllegalArgumentException("Orders list is null or empty");
        }
        final UserEntity existsUser = userService.get(userId);
        entities.forEach(entity -> entity.setUser(existsUser));
        return StreamSupport.stream(repository.saveAll(entities).spliterator(), false).toList();
    }

    @Transactional
    public OrderEntity update(long userId, long id, OrderEntity entity) {
        userService.get(userId);
        final OrderEntity existsEntity = get(userId, id);
        existsEntity.setType(entity.getType());
        existsEntity.setPrice(entity.getPrice());
        existsEntity.setCount(entity.getCount());
        existsEntity.setImageExtension(entity.getImageExtension());
        existsEntity.setImage(entity.getImage());
        return repository.save(existsEntity);
    }

    @Transactional
    public OrderEntity delete(long userId, long id) {
        userService.get(userId);
        final OrderEntity existsEntity = get(userId, id);
        repository.delete(existsEntity);
        return existsEntity;
    }

    @Transactional(readOnly = true)
    public List<OrderGrouped> getTotal(long userId) {
        userService.get(userId);
        return repository.getOrdersTotalByType(userId);
    }
}
