package com.example.demo.core.file;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

public class FileHelper {
    private static final Logger log = LoggerFactory.getLogger(FileHelper.class);

    private FileHelper() {
    }

    public static String getExtension(MultipartFile file) {
        final String fileName = file.getOriginalFilename();
        if (fileName == null) {
            return null;
        }
        final int lastIndex = fileName.lastIndexOf('.');
        return fileName.substring(lastIndex, fileName.length()).replaceFirst("\\.", "");
    }

    // MultipartFile доступен только в пределах запроса
    // Чтобы файл существовал до создания заказа, необходимо его скопировать во
    // временных каталог
    public static Path toTmpPath(MultipartFile file, Path storagePath) {
        if (file.isEmpty()) {
            return null;
        }
        try {
            final Path dest = Path.of(
                    storagePath.toFile().getAbsolutePath(),
                    String.format("%s-%s", UUID.randomUUID().toString(), file.getOriginalFilename()));
            file.transferTo(dest);
            return dest;
        } catch (IOException e) {
            throw new InternalError(e);
        }
    }

    public static byte[] getFileBytes(Path file) {
        if (!Files.exists(file)) {
            throw new IllegalArgumentException("File is not exists");
        }
        try {
            final byte[] data = Files.readAllBytes(file);
            Files.delete(file);
            return data;
        } catch (IOException e) {
            log.error("File upload error", e);
            return new byte[0];
        }
    }

    public static String saveToFile(Path path, long id, String extension, byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }
        try {
            final Path dir = Path.of(
                    path.toFile().getAbsolutePath(),
                    "resources/image");
            if (!Files.exists(dir)) {
                Files.createDirectories(dir);
            }
            final Path temp = Path.of(
                    dir.toFile().getAbsolutePath(),
                    String.format("order-%s.%s", id, extension));
            Files.write(temp, bytes);
            return temp.toFile().getAbsolutePath();
        } catch (IOException e) {
            throw new InternalError(e);
        }
    }
}
