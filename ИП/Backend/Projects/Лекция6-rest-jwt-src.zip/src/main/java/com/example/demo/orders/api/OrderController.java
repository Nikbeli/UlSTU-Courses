package com.example.demo.orders.api;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.core.api.PageDto;
import com.example.demo.core.api.PageDtoMapper;
import com.example.demo.core.configuration.Constants;
import com.example.demo.core.security.UserPrincipal;
import com.example.demo.orders.model.OrderEntity;
import com.example.demo.orders.model.OrderGrouped;
import com.example.demo.orders.service.OrderService;
import com.example.demo.types.service.TypeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping(Constants.API_URL + "/order")
public class OrderController {
    private final OrderService orderService;
    private final TypeService typeService;
    private final ModelMapper modelMapper;

    public OrderController(OrderService orderService, TypeService typeService, ModelMapper modelMapper) {
        this.orderService = orderService;
        this.typeService = typeService;
        this.modelMapper = modelMapper;
    }

    private OrderDto toDto(OrderEntity entity) {
        return modelMapper.map(entity, OrderDto.class);
    }

    private OrderEntity toEntity(OrderDto dto) {
        final OrderEntity entity = modelMapper.map(dto, OrderEntity.class);
        entity.setType(typeService.get(dto.getTypeId()));
        return entity;
    }

    private OrderGroupedDto toGroupedDto(OrderGrouped entity) {
        return modelMapper.map(entity, OrderGroupedDto.class);
    }

    @GetMapping
    public PageDto<OrderDto> getAll(
            @RequestParam(name = "typeId", defaultValue = "0") Long typeId,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = Constants.DEFAULT_PAGE_SIZE) int size,
            @AuthenticationPrincipal UserPrincipal principal) {
        return PageDtoMapper.toDto(orderService.getAll(principal.getId(), typeId, page, size), this::toDto);
    }

    @GetMapping("/{id}")
    public OrderDto get(
            @PathVariable(name = "id") Long id,
            @AuthenticationPrincipal UserPrincipal principal) {
        return toDto(orderService.get(principal.getId(), id));
    }

    @PostMapping
    public OrderDto create(
            @RequestBody @Valid OrderDto dto,
            @AuthenticationPrincipal UserPrincipal principal) {
        return toDto(orderService.create(principal.getId(), toEntity(dto)));
    }

    @PutMapping("/{id}")
    public OrderDto update(
            @PathVariable(name = "id") Long id,
            @RequestBody @Valid OrderDto dto,
            @AuthenticationPrincipal UserPrincipal principal) {
        return toDto(orderService.update(principal.getId(), id, toEntity(dto)));
    }

    @DeleteMapping("/{id}")
    public OrderDto delete(
            @PathVariable(name = "id") Long id,
            @AuthenticationPrincipal UserPrincipal principal) {
        return toDto(orderService.delete(principal.getId(), id));
    }

    @GetMapping("/total")
    public List<OrderGroupedDto> getMethodName(@AuthenticationPrincipal UserPrincipal principal) {
        return orderService.getTotal(principal.getId()).stream()
                .map(this::toGroupedDto)
                .toList();
    }

}
