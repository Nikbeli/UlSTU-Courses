package com.example.demo;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api-test")
public class ApiController {
    private final Logger log = LoggerFactory.getLogger(ApiController.class);
    // List<TestDto> data = new ArrayList<>();
    // List<TestDto> getAll() @GetMapping
    // TestDto get(@PathVariable() int id) @GetMapping("/{id}")
    // TestDto create(@RequestBody TestDto obj) @PostMapping
    // TestDto update(@PathVariable() int id, @RequestBody TestDto obj)
    // @PutMapping("/{id}")
    // TestDto delete(@PathVariable() int id) @DeleteMapping("/{id}")

    @GetMapping
    public String get(@RequestParam(name = "name", defaultValue = "World") String name) {
        return String.format("Hello, %s", name);
    }

    @GetMapping("/{id}")
    public Integer getMethodName(@PathVariable(name = "id") Integer id) {
        return id;
    }

    @GetMapping("/test")
    public String getTest() {
        return new Date().toString();
    }

    @GetMapping("/num")
    public Integer getNum() {
        return 10;
    }

    @GetMapping("/list")
    public List<Integer> getList() {
        return List.of(10, 20, 30, 40, 50);
    }

    @GetMapping("/map")
    public TestDto getMap() {
        return new TestDto("Ivanov", "Ivan");
    }

    @PostMapping("/map")
    public TestDto postMap(@RequestBody TestDto testDto) {
        return testDto;
    }

    @PostMapping
    public String postMethodName(@RequestBody String name) {
        return get(name);
    }

    @DeleteMapping("/{name}")
    public String putMethodName(@PathVariable(name = "name") String name, @RequestBody String entity) {
        log.info("The body value is {}", entity);
        return get(name);
    }
}
