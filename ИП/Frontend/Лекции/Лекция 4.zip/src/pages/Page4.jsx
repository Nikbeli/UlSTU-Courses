import { Button, ButtonGroup, Table } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const Page4 = () => {
    return (
        <>
            <ButtonGroup>
                <Button id="items-add" variant="info">Добавить товар (диалог)</Button>
                <Button as={Link} to="/page-edit" variant="success">Добавить товар (страница)</Button>
            </ButtonGroup>
            <Table className="mt-2" striped>
                <thead>
                    <th scope="col">№</th>
                    <th scope="col" className="w-25">Товар</th>
                    <th scope="col" className="w-25">Цена</th>
                    <th scope="col" className="w-25">Количество</th>
                    <th scope="col" className="w-25">Сумма</th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                </thead>
                <tbody></tbody>
            </Table>
        </>
    );
};

export default Page4;
