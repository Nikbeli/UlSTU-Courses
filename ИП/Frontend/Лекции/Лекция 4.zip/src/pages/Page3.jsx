import { useState } from 'react';
import { Button, Form } from 'react-bootstrap';

const Page3 = () => {
    const [validated, setValidated] = useState(false);

    const handleSubmit = (event) => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
        }

        setValidated(true);
    };

    return (
        <div className="row justify-content-center">
            <Form className="col-md-6 m-0" noValidate validated={validated} onSubmit={handleSubmit}>
                <Form.Group className="mb-2" controlId="lastname">
                    <Form.Label>Фамилия</Form.Label>
                    <Form.Control type="text" name="lastname" required />
                    <Form.Control.Feedback>Фамилия заполнена</Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">Фамилия не заполнена</Form.Control.Feedback>
                </Form.Group>
                <Form.Group className="mb-2" controlId="firstname">
                    <Form.Label>Имя</Form.Label>
                    <Form.Control type="text" name="firstname" required />
                </Form.Group>
                <Form.Group className="mb-2" controlId="email">
                    <Form.Label>E-mail</Form.Label>
                    <Form.Control type="email" name="email" placeholder="name@example.ru" required />
                </Form.Group>
                <Form.Group className="mb-2" controlId="password">
                    <Form.Label>Пароль</Form.Label>
                    <Form.Control type="password" name="password" required />
                </Form.Group>
                <Form.Group className="mb-2" controlId="date">
                    <Form.Label>Дата</Form.Label>
                    <Form.Control type="date" name="date" required />
                </Form.Group>
                <Form.Group className="mb-2" controlId="disabled">
                    <Form.Label>Выключенный компонент</Form.Label>
                    <Form.Control type="text" name="disabled" value="Некоторое значение" disabled />
                </Form.Group>
                <Form.Group className="mb-2" controlId="readonly">
                    <Form.Label>Компонент только для чтения</Form.Label>
                    <Form.Control type="text" name="readonly" value="Некоторое значение" readOnly />
                </Form.Group>
                <Form.Group className="mb-2" controlId="color">
                    <Form.Label>Выбор цвета</Form.Label>
                    <Form.Control type="color" name="color" defaultValue='#ff0055' />
                </Form.Group>
                <Form.Group className="mb-2 d-md-flex flex-md-row">
                    <Form.Check className="me-md-3" type='checkbox' name='checkbox1' label='Флажок 1' />
                    <Form.Check className="me-md-3" type='checkbox' name='checkbox2' label='Флажок 2' />
                </Form.Group>
                <Form.Group className="mb-2 d-md-flex flex-md-row">
                    <Form.Check className="me-md-3" type='radio' name='radio1' label='Переключатель 1' />
                    <Form.Check className="me-md-3" type='switch' name='radio2' label='Переключатель 2' />
                </Form.Group>
                <Form.Group className="mb-2">
                    <Form.Select name='selected' required>
                        <option value="" selected>Выберите значение</option>
                        <option value="1">Один</option>
                        <option value="2">Два</option>
                        <option value="3">Три</option>
                    </Form.Select>
                </Form.Group>
                <div className="text-center">
                    <Button className="w-50" variant="primary" type="submit">Отправить</Button>
                </div>
            </Form>
        </div>
    );
};

export default Page3;
