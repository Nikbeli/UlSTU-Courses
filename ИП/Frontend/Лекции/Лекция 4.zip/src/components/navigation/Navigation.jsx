import PropTypes from 'prop-types';
import { Container, Nav, Navbar } from 'react-bootstrap';
import { Cart2 } from 'react-bootstrap-icons';
import { Link, useLocation } from 'react-router-dom';
import './Navigation.css';

const Navigation = ({ routes }) => {
    const location = useLocation();
    const indexPageLink = routes.filter((route) => route.index === false).shift();
    const pages = routes.filter((route) => Object.prototype.hasOwnProperty.call(route, 'title'));

    return (
        <header>
            <Navbar expand='md' bg='dark' data-bs-theme='dark' className='my-navbar'>
                <Container fluid>
                    <Navbar.Brand as={Link} to={indexPageLink?.path ?? '/'}>
                        <Cart2 className='d-inline-block align-top me-1 logo' />
                        My shop
                    </Navbar.Brand>
                    <Navbar.Toggle aria-controls='main-navbar' />
                    <Navbar.Collapse id='main-navbar'>
                        <Nav className='me-auto link' activeKey={location.pathname}>
                            {
                                pages.map((page) =>
                                    <Nav.Link as={Link} key={page.path} eventKey={page.path} to={page.path ?? '/'}>
                                        {page.title}
                                    </Nav.Link>)
                            }
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar >
        </header>
    );
};

Navigation.propTypes = {
    routes: PropTypes.array,
};

export default Navigation;
