import { resolve } from "path";
// eslint-disable-next-line import/no-extraneous-dependencies
import { defineConfig } from "vite";

export default defineConfig({
    build: {
        sourcemap: true,
        emptyOutDir: true,
        rollupOptions: {
            input: {
                main: resolve(__dirname, "index.html"),
                page2: resolve(__dirname, "page2.html"),
                page3: resolve(__dirname, "page3.html"),
                page4: resolve(__dirname, "page4.html"),
            },
        },
    },
});
