### Окружение

В VSCode необходимо установить плагин (расширение) ESLint:

https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint

ESLint уже настроен (см. конфиг .eslintrc.json), но для справки можно почитать материал по ссылке

https://www.digitalocean.com/community/tutorials/linting-and-formatting-with-eslint-in-vs-code

### Установка зависимостей

npm install

### Запуск в режиме разработки

npm run dev

### Запуск продуктовой версии (production)

npm run prod