// модуль для работы с REST API сервера

// адрес сервера
const serverUrl = "http://localhost:8081";

// функция возвращает объект нужной структуры для отправки на сервер
function createLineObject(item, price, count, image) {
    return {
        itemsId: item,
        price: parseFloat(price).toFixed(2),
        count,
        sum: parseFloat(price * count).toFixed(2),
        image,
    };
}

// обращение к серверу для получения всех типов товара (get)
export async function getAllItemTypes() {
    const response = await fetch(`${serverUrl}/items`);
    if (!response.ok) {
        throw response.statusText;
    }
    return response.json();
}

// обращение к серверу для получения всех записей (get)
export async function getAllLines() {
    const response = await fetch(`${serverUrl}/lines?_expand=items`);
    if (!response.ok) {
        throw response.statusText;
    }
    return response.json();
}

// обращение к серверу для получения записи по первичному ключу (id) (get)
// id передается в качестве части пути URL get-запроса
export async function getLine(id) {
    const response = await fetch(`${serverUrl}/lines/${id}?_expand=items`);
    if (!response.ok) {
        throw response.statusText;
    }
    return response.json();
}

// обращение к серверу для создания записи (post)
// объект отправляется в теле запроса (body)
export async function createLine(item, price, count, image) {
    const itemObject = createLineObject(item, price, count, image);

    const options = {
        method: "POST",
        body: JSON.stringify(itemObject),
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json",
        },
    };

    const response = await fetch(`${serverUrl}/lines`, options);
    if (!response.ok) {
        throw response.statusText;
    }
    return response.json();
}

// обращение к серверу для обновления записи по id (put)
// объект отправляется в теле запроса (body)
// id передается в качестве части пути URL get-запроса
export async function updateLine(id, item, price, count, image) {
    const itemObject = createLineObject(item, price, count, image);

    const options = {
        method: "PUT",
        body: JSON.stringify(itemObject),
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json",
        },
    };

    const response = await fetch(`${serverUrl}/lines/${id}`, options);
    if (!response.ok) {
        throw response.statusText;
    }
    return response.json();
}

// обращение к серверу для удаления записи по id (delete)
// id передается в качестве части пути URL get-запроса
export async function deleteLine(id) {
    const options = {
        method: "DELETE",
    };

    const response = await fetch(`${serverUrl}/lines/${id}`, options);
    if (!response.ok) {
        throw response.statusText;
    }
    return response.json();
}
