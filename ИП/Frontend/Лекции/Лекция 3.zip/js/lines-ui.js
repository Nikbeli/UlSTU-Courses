// модуль для работы с элементами управления

// объект для удобного получения элементов
// при обращении к атрибуту объекта вызывается
// нужная функция для поиска элемента
export const cntrls = {
    button: document.getElementById("items-add"),
    table: document.querySelector("#items-table tbody"),
    form: document.getElementById("items-form"),
    lineId: document.getElementById("items-line-id"),
    itemsType: document.getElementById("item"),
    price: document.getElementById("price"),
    count: document.getElementById("count"),
    image: document.getElementById("image"),
    imagePreview: document.getElementById("image-preview"),
};

// Дефолтное превью
export const imagePlaceholder = "https://via.placeholder.com/200";

// функция создает тег option для select
// <option value="" selected>name</option>
export function createItemsOption(name, value = "", isSelected = false) {
    const option = document.createElement("option");
    option.value = value || "";
    option.selected = isSelected;
    option.text = name;
    return option;
}

// функция создает ссылку (a) для таблицы
// содержимое тега a заполняется необходимой иконкой (icon)
// при нажатии вызывается callback
// ссылка "оборачивается" тегом td
// <td><a href="#" onclick="callback()"><i class="fa-solid icon"></i></a></td>
function createTableAnchor(icon, callback) {
    const i = document.createElement("i");
    i.classList.add("fa-solid", icon);

    const a = document.createElement("a");
    a.href = "#";
    a.appendChild(i);
    a.onclick = (event) => {
        // чтобы в URL не добавлялась решетка
        event.preventDefault();
        event.stopPropagation();
        callback();
    };

    const td = document.createElement("td");
    td.appendChild(a);
    return td;
}

// функция создает колонку таблицы с текстом value
// <td>value</td>
function createTableColumn(value) {
    const td = document.createElement("td");
    td.textContent = value;
    return td;
}

// функция создает строку таблицы
// <tr>
// <th scope="row">index + 1</th>
// <td>item.items.name</td>
// <td>parseFloat(item.price).toFixed(2))</td>
// <td>item.count</td>
// <td>parseFloat(item.sum).toFixed(2))</td>
// <td><a href="#" onclick="editCallback()"><i class="fa-solid fa-pencil"></i></a></td>
// <td><a href="#" onclick="editPageCallback()"><i class="fa-solid fa-pen-to-square"></i></a></td>
// <td><a href="#" onclick="deleteCallback()"><i class="fa-solid fa-trash"></i></a></td>
// </tr>
export function createTableRow(item, index, editCallback, editPageCallback, deleteCallback) {
    const rowNumber = document.createElement("th");
    rowNumber.scope = "row";
    rowNumber.textContent = index + 1;

    const row = document.createElement("tr");
    row.id = `line-${item.id}`;

    row.appendChild(rowNumber);
    row.appendChild(createTableColumn(item.items.name));
    row.appendChild(createTableColumn(parseFloat(item.price).toFixed(2)));
    row.appendChild(createTableColumn(item.count));
    row.appendChild(createTableColumn(parseFloat(item.sum).toFixed(2)));
    // редактировать в модальном окне
    row.appendChild(createTableAnchor("fa-pencil", editCallback));
    // редактировать на странице page-edit
    row.appendChild(createTableAnchor("fa-pen-to-square", editPageCallback));
    // удаление
    row.appendChild(createTableAnchor("fa-trash", deleteCallback));
    return row;
}
