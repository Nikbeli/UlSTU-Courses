/* eslint-disable import/no-extraneous-dependencies */
import vue from "@vitejs/plugin-vue";
import { defineConfig } from "vite";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [vue()],
  build: {
    sourcemap: true,
    chunkSizeWarningLimit: 1024,
    emptyOutDir: true,
  },
});
