### Окружение:

- [nodejs 20 LTS latest](https://nodejs.org/en/download/);
- [VSCode](https://code.visualstudio.com/download);
- [ESLint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint) плагин для VSCode;
- [CSS Class Intellisense](https://marketplace.visualstudio.com/items?itemName=Tarrow.css-class-intellisense) плагин для автодополнения CSS-классов в HTML;
- для отладки необходимы бразузеры Chrome или Edge.

Настройки плагина CSS Class Intellisense находятся в файле ./vscode/cssconfig.json

### Команды

#### Создание пустого проекта:

```commandline
npm create vite@latest ./ -- --template vue
```

#### Установка зависимостей:

```commandline
npm install
```

#### Запуск проекта в режиме разработки (development):

```commandline
npm run dev
```

#### Запуск проекта в продуктовом режиме (production):

```commandline
npm run prod
```

### Полезные ссылки

1. Документация Vue - https://vuejs.org/guide/introduction.html
2. События жизненного цикла - https://vuejs.org/guide/essentials/lifecycle.html
3. Основы компонентов - https://vuejs.org/guide/essentials/component-basics.html
4. Композиция - https://vuejs.org/guide/reusability/composables.html
5. Управление состоянием - https://vuejs.org/guide/scaling-up/state-management.html
6. Работа с формами - https://vuejs.org/guide/essentials/forms.html
7. Реактивность - https://vuejs.org/api/reactivity-core.html#computed
8. Маршрутизация - https://router.vuejs.org/guide/
