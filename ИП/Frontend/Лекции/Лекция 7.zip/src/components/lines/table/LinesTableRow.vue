<script setup>
defineProps({
  index: { type: Number, required: true },
  line: { type: Object, required: true },
});
defineEmits(["add-to-cart", "edit", "edit-in-page", "delete"]);
</script>

<template>
  <tr>
    <th scope="row">{{ index + 1 }}</th>
    <td>{{ line.type.name }}</td>
    <td>{{ parseFloat(line.price).toFixed(2) }}</td>
    <td>{{ line.count }}</td>
    <td>{{ parseFloat(line.sum).toFixed(2) }}</td>
    <td>
      <a href="#" @click.stop.prevent="$emit('add-to-cart')"
        ><i class="bi bi-cart"></i
      ></a>
    </td>
    <td>
      <a href="#" @click.stop.prevent="$emit('edit')"
        ><i class="bi bi-pencil-fill"></i
      ></a>
    </td>
    <td>
      <a href="#" @click.stop.prevent="$emit('edit-in-page')"
        ><i class="bi bi-pencil-square"></i
      ></a>
    </td>
    <td>
      <a href="#" @click.stop.prevent="$emit('delete')"
        ><i class="bi bi-trash3"></i
      ></a>
    </td>
  </tr>
</template>
