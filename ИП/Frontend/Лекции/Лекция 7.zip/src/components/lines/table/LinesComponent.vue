<script setup>
import { RouterLink, useRouter } from "vue-router";
import { addToCart } from "../../cart/CartStorage";
import SelectComponent from "../../input/SelectComponent.vue";
import ModalConfirm from "../../modal/ModalConfirm.vue";
import ModalForm from "../../modal/ModalForm.vue";
import LinesItemForm from "../form/LinesItemForm.vue";
import useLinesDeleteModal from "../hooks/LinesDeleteModalHook";
import useTypeFilter from "../hooks/LinesFilterHook";
import useLinesFormModal from "../hooks/LinesFormModalHook";
import useLines from "../hooks/LinesHook";
import LinesTable from "./LinesTable.vue";
import LinesTableRow from "./LinesTableRow.vue";

const { types, currentFilter, handleFilterChange } = useTypeFilter();
const { lines, handleLinesChange } = useLines(currentFilter);

const {
  isDeleteModalShow,
  showDeleteModal,
  handleDeleteConfirm,
  handleDeleteCancel,
} = useLinesDeleteModal(handleLinesChange);

const {
  isFormModalShow,
  showFormModal,
  currentItem,
  handleFormSubmit,
  handleFormClose,
} = useLinesFormModal(handleLinesChange);

const router = useRouter();
const showEditPage = (id) => {
  router.push({ path: `/page-edit/${id}` });
};
</script>

<template>
  <div class="btn-group" role="group" aria-label="Lines buttons">
    <button type="button" class="btn btn-info" @click="showFormModal">
      Добавить товар (диалог)
    </button>
    <RouterLink type="button" class="btn btn-success" to="/page-edit">
      Добавить товар (страница)
    </RouterLink>
  </div>
  <SelectComponent
    name="filter"
    class="mt-2"
    :values="types"
    label="Фильтр по товарам"
    :value="currentFilter"
    @change="handleFilterChange"
  />
  <LinesTable>
    <LinesTableRow
      v-for="(line, index) in lines"
      :key="line.id"
      :index="index"
      :line="line"
      @add-to-cart="addToCart(line)"
      @edit="showFormModal(line.id)"
      @edit-in-page="showEditPage(line.id)"
      @delete="showDeleteModal(line.id)"
    />
  </LinesTable>
  <ModalConfirm
    :show="isDeleteModalShow"
    title="Удаление"
    message="Удалить элемент?"
    @confirm="handleDeleteConfirm"
    @close="handleDeleteCancel"
  />
  <ModalForm
    :show="isFormModalShow"
    title="Редактирование"
    @submit="handleFormSubmit"
    @close="handleFormClose"
  >
    <lines-item-form v-model:item="currentItem" />
  </ModalForm>
</template>
