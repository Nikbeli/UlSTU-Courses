<template>
  <table class="table table-striped table-responsive mt-2">
    <thead>
      <tr>
        <th scope="col">№</th>
        <th scope="col" className="w-25">Товар</th>
        <th scope="col" className="w-25">Цена</th>
        <th scope="col" className="w-25">Колич.</th>
        <th scope="col" className="w-25">Сумма</th>
        <th scope="col"></th>
        <th scope="col"></th>
        <th scope="col"></th>
        <th scope="col"></th>
      </tr>
    </thead>
    <tbody>
      <slot></slot>
    </tbody>
  </table>
</template>
