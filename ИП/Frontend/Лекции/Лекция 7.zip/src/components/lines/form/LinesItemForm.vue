<script setup>
import { computed } from "vue";
import imgPlaceholder from "../../../assets/200.png";
import ImageComponent from "../../input/ImageComponent.vue";
import InputComponent from "../../input/InputComponent.vue";
import SelectComponent from "../../input/SelectComponent.vue";
import useTypes from "../../types/hooks/TypesHook";

const props = defineProps({
  item: { type: Object, required: true },
});
const emit = defineEmits({
  "update:item": (value) => {
    if (value) {
      return true;
    }
    console.warn("Invalid item change event payload");
    return false;
  },
});

const localItem = computed({
  get() {
    return props.item;
  },
  set(value) {
    emit("update:item", value);
  },
});

const { types } = useTypes();
</script>

<template>
  <div class="text-center mb-2">
    <img
      id="image-preview"
      :src="localItem.image || imgPlaceholder"
      class="rounded rounded-circle"
      alt="placeholder"
    />
  </div>
  <SelectComponent
    v-model="localItem.typeId"
    name="typeId"
    label="Тип товара"
    :values="types"
    required
  />
  <InputComponent
    v-model="localItem.price"
    name="price"
    label="Цена"
    type="number"
    min="1000.0"
    step="0.50"
    required
  />
  <InputComponent
    v-model="localItem.count"
    name="count"
    label="Количество"
    type="number"
    min="1"
    step="1"
    required
  />
  <ImageComponent
    name="image"
    label="Изображение"
    @image="(image) => (localItem.image = image)"
  />
</template>

<style scoped>
#image-preview {
  width: 200px;
}
</style>
