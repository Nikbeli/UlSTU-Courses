<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import FormComponent from "../../form/FormComponent.vue";
import useLinesItemForm from "../hooks/LinesItemFormHook";
import LinesItemForm from "./LinesItemForm.vue";

const props = defineProps({
  linesId: { type: Number, required: true },
});

const router = useRouter();
const currentId = ref(props.linesId);

const { item, handleSubmit } = useLinesItemForm(currentId);

const onBack = () => {
  router.push("/page4");
};
const onSubmit = async () => {
  await handleSubmit();
  onBack();
};
</script>

<template>
  <FormComponent @submit="onSubmit">
    <LinesItemForm v-model:item="item" />
    <div class="form-group row justify-content-center m-0 mt-3">
      <button class="btn btn-secondary col-5 col-lg-2 m-0 me-2" @click="onBack">
        Назад
      </button>
      <button type="submit" class="btn btn-primary col-5 col-lg-2 m-0 ms-2">
        Сохранить
      </button>
    </div>
  </FormComponent>
</template>
