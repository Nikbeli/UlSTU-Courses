import { reactive, watchEffect } from "vue";
import LinesApiService from "../service/LinesApiService";

const useLinesItem = (id) => {
  const emptyItem = {
    id: "",
    typeId: "",
    price: "0",
    count: "0",
    sum: "0",
    image: "",
  };
  const item = reactive({ ...emptyItem });

  const getItem = async (itemId) => {
    if (itemId && itemId > 0) {
      const data = await LinesApiService.get(itemId);
      Object.assign(item, data);
    } else {
      Object.assign(item, { ...emptyItem });
    }
  };

  watchEffect(() => getItem(id.value));

  return {
    item,
  };
};

export default useLinesItem;
