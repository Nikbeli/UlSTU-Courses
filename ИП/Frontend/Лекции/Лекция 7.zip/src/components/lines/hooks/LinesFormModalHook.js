import { ref } from "vue";
import useModal from "../../modal/ModalHook";
import useLinesItemForm from "./LinesItemFormHook";

const useLinesFormModal = (linesChangeHandle) => {
  const { isModalShow, showModal, hideModal } = useModal();
  const currentId = ref(0);

  const { item, handleSubmit } = useLinesItemForm(currentId, linesChangeHandle);

  const showModalDialog = (id) => {
    currentId.value = id;
    showModal();
  };

  const onClose = () => {
    currentId.value = 0;
    hideModal();
  };

  const onSubmit = async () => {
    await handleSubmit();
    onClose();
  };

  return {
    isFormModalShow: isModalShow,
    showFormModal: showModalDialog,
    currentItem: item,
    handleFormSubmit: onSubmit,
    handleFormClose: onClose,
  };
};

export default useLinesFormModal;
