import { inject } from "vue";
import LinesApiService from "../service/LinesApiService";
import useLinesItem from "./LinesItemHook";

const useLinesItemForm = (id, linesChangeHandle) => {
  const toast = inject("$toast");

  const { item } = useLinesItem(id);

  const getLineObject = (formData) => {
    const typeId = parseInt(formData.typeId, 10);
    const price = parseFloat(formData.price).toFixed(2);
    const count = parseInt(formData.count, 10);
    const sum = parseFloat(price * count).toFixed(2);
    const image = formData.image.startsWith("data:image") ? formData.image : "";
    return {
      typeId: typeId.toString(),
      price: price.toString(),
      count: count.toString(),
      sum: sum.toString(),
      image,
    };
  };

  const handleSubmit = async () => {
    const currentId = id.value;
    const body = getLineObject(item);
    if (currentId && currentId > 0) {
      await LinesApiService.update(currentId, body);
    } else {
      await LinesApiService.create(body);
    }
    if (linesChangeHandle) linesChangeHandle();
    toast.success("Элемент успешно сохранен");
  };

  return {
    item,
    handleSubmit,
  };
};

export default useLinesItemForm;
