import { ref, watch } from "vue";
import LinesApiService from "../service/LinesApiService";

const useLines = (currentFilter) => {
  const linesRefresh = ref(false);
  const lines = ref([]);
  const handleLinesChange = () => {
    linesRefresh.value = !linesRefresh.value;
  };

  const getLines = async () => {
    let expand = "?_expand=type";
    if (currentFilter.value) {
      expand = `${expand}&typeId=${currentFilter.value}`;
    }
    const data = await LinesApiService.getAll(expand);
    lines.value = data ?? [];
  };

  watch(
    [linesRefresh, currentFilter],
    () => {
      getLines();
    },
    { immediate: true },
  );

  return {
    lines,
    handleLinesChange,
  };
};

export default useLines;
