import { computed } from "vue";
import { useRoute, useRouter } from "vue-router";
import useTypes from "../../types/hooks/TypesHook";

const useTypeFilter = () => {
  const route = useRoute();
  const router = useRouter();

  const { types } = useTypes();

  const handleFilterChange = (event) => {
    const type = event.target.value;
    if (type) {
      router.push({ path: route.path, query: { type } });
    } else {
      router.push({ path: route.path, query: {} });
    }
  };

  return {
    types,
    currentFilter: computed(() => route.query.type || ""),
    handleFilterChange,
  };
};

export default useTypeFilter;
