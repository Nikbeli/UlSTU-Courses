import { inject, ref } from "vue";
import useModal from "../../modal/ModalHook";
import LinesApiService from "../service/LinesApiService";

const useLinesDeleteModal = (linesChangeHandle) => {
  const toast = inject("$toast");
  const { isModalShow, showModal, hideModal } = useModal();
  const currentId = ref(0);

  const showModalDialog = (id) => {
    showModal();
    currentId.value = id;
  };

  const onClose = () => {
    hideModal();
  };

  const onDelete = async () => {
    await LinesApiService.delete(currentId.value);
    linesChangeHandle();
    toast.success("Элемент успешно удален");
    onClose();
  };

  return {
    isDeleteModalShow: isModalShow,
    showDeleteModal: showModalDialog,
    handleDeleteConfirm: onDelete,
    handleDeleteCancel: onClose,
  };
};

export default useLinesDeleteModal;
