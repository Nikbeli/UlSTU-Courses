<script setup>
import getBase64FromFile from "../utils/Base64";
import useAttributes from "./AttributesHook";

defineProps({
  name: { type: String, required: true },
  label: { type: String, required: true },
});
const emit = defineEmits({
  image: (value) => {
    if (value) {
      return true;
    }
    console.warn("Invalid image event payload");
    return false;
  },
});
defineOptions({
  inheritAttrs: false,
});

const { classes, childAttrs } = useAttributes();

const onChange = async (event) => {
  const { files } = event.target;
  const file = await getBase64FromFile(files.item(0));
  emit("image", file);
};
</script>

<template>
  <div class="mb-2" v-bind="classes">
    <label class="form-label" :for="name">{{ label }}</label>
    <input
      :id="name"
      value=""
      :name="name"
      class="form-control"
      type="file"
      accept="image/*"
      v-bind="childAttrs"
      @input="onChange"
    />
  </div>
</template>
