<script setup>
import useAttributes from "./AttributesHook";

defineProps({
  name: { type: String, required: true },
  label: { type: String, required: true },
  modelValue: { type: String, default: "" },
});
const emit = defineEmits(["update:modelValue"]);
defineOptions({
  inheritAttrs: false,
});

const { classes, childAttrs } = useAttributes();

const onChange = (event) => {
  if (event.target.type === "file") {
    throw Error("File input");
  }
  const inputValue =
    event.target.type === "checkbox"
      ? event.target.checked
      : event.target.value;
  emit("update:modelValue", inputValue);
};
</script>

<template>
  <div class="mb-2" v-bind="classes">
    <label class="form-label" :for="name">{{ label }}</label>
    <input
      :id="name"
      :value="modelValue"
      :name="name"
      class="form-control"
      v-bind="childAttrs"
      @input="onChange"
    />
  </div>
</template>
