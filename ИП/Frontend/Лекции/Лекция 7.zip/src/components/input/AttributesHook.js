import { useAttrs } from "vue";

const useAttributes = () => {
  const attrs = useAttrs();
  const classes = { class: attrs.class };
  const childAttrs = { ...attrs, class: "" };

  return {
    classes,
    childAttrs,
  };
};

export default useAttributes;
