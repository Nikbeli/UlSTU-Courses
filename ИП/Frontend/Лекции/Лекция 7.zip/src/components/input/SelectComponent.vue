<script setup>
import useAttributes from "./AttributesHook";

defineProps({
  values: { type: Array, required: true },
  name: { type: String, required: true },
  label: { type: String, required: true },
  modelValue: { type: String, default: "" },
});
const emit = defineEmits(["update:modelValue"]);
defineOptions({
  inheritAttrs: false,
});

const { classes, childAttrs } = useAttributes();

const onChange = (event) => {
  emit("update:modelValue", event.target.value);
};
</script>

<template>
  <div class="mb-2" v-bind="classes">
    <label :for="name" class="form-label">{{ label }}</label>
    <select
      :id="name"
      :value="modelValue"
      class="form-select"
      :name="name"
      v-bind="childAttrs"
      @change="onChange"
    >
      <option value="">Выберите значение</option>
      <option v-for="current in values" :key="current.id" :value="current.id">
        {{ current.name }}
      </option>
    </select>
  </div>
</template>
