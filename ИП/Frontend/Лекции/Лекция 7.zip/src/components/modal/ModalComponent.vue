<script setup>
defineProps({
  show: { type: Boolean, required: true },
  title: { type: String, required: true },
});
defineEmits(["close"]);
</script>

<template>
  <Teleport to="body">
    <Transition>
      <div
        v-if="show"
        class="modal show"
        tabindex="-1"
        data-bs-backdrop="static"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header pt-2 pb-2 ps-3 pe-3">
              <h5 class="modal-title">Modal title</h5>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
                @click="$emit('close')"
              ></button>
            </div>
            <slot></slot>
          </div>
        </div>
      </div>
    </Transition>
    <Transition>
      <div v-if="show" class="modal-backdrop show"></div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.modal-title {
  font-size: 1.2rem;
}
.modal.show {
  display: block;
}
.v-enter-active,
.v-leave-active {
  transition: opacity 0.2s ease-out;
}
.v-enter-from,
.v-leave-to {
  opacity: 0;
}
</style>
