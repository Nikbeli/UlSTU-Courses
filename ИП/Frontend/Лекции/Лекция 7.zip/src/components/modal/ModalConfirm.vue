<script setup>
import ModalComponent from "./ModalComponent.vue";

defineProps({
  show: { type: Boolean, required: true },
  title: { type: String, required: true },
  message: { type: String, required: true },
});
defineEmits(["confirm", "close"]);
</script>

<template>
  <ModalComponent :show="show" :title="title" @close="$emit('close')">
    <div class="modal-body">
      {{ message }}
    </div>
    <div
      class="modal-footer m-0 pt-2 pb-2 ps-3 pe-3 row justify-content-center"
    >
      <button
        type="button"
        class="btn btn-secondary col-5 m-0 me-2"
        @click="$emit('close')"
      >
        Нет
      </button>
      <button
        type="button"
        class="btn btn-primary col-5 m-0 ms-2"
        @click="$emit('confirm')"
      >
        Да
      </button>
    </div>
  </ModalComponent>
</template>
