<script setup>
import FormComponent from "../form/FormComponent.vue";
import ModalComponent from "./ModalComponent.vue";

defineProps({
  show: { type: Boolean, required: true },
  title: { type: String, required: true },
});
defineEmits(["submit", "close"]);
</script>

<template>
  <ModalComponent :show="show" :title="title" @close="$emit('close')">
    <FormComponent @submit="$emit('submit')">
      <div class="modal-body">
        <slot></slot>
      </div>
      <div
        class="modal-footer m-0 pt-2 pb-2 ps-3 pe-3 row justify-content-center"
      >
        <button
          type="button"
          class="btn btn-secondary col-5 m-0 me-2"
          @click="$emit('close')"
        >
          Отмена
        </button>
        <button type="submit" class="btn btn-primary col-5 m-0 ms-2">
          Сохранить
        </button>
      </div>
    </FormComponent>
  </ModalComponent>
</template>
