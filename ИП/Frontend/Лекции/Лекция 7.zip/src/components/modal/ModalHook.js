import { computed, ref } from "vue";

const useModal = () => {
  const showModal = ref(false);

  const showModalDialog = () => {
    showModal.value = true;
  };

  const hideModalDialog = () => {
    showModal.value = false;
  };

  return {
    isModalShow: computed(() => showModal.value),
    showModal: showModalDialog,
    hideModal: hideModalDialog,
  };
};

export default useModal;
