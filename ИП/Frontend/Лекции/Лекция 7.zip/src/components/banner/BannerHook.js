import { onMounted, onUnmounted, ref } from "vue";
import banner1 from "../../assets/banner1.png";
import banner2 from "../../assets/banner2.png";
import banner3 from "../../assets/banner3.png";

const useBannerHook = () => {
  const currentBanner = ref(0);
  const banners = [banner1, banner2, banner3];

  const getBannerClass = (index) => {
    return currentBanner.value === index ? "banner-show" : "banner-hide";
  };

  let bannerInterval = null;

  onMounted(() => {
    bannerInterval = setInterval(() => {
      console.info("Banner changed");
      let current = currentBanner.value + 1;
      if (current === banners.length) {
        current = 0;
      }
      currentBanner.value = current;
    }, 5000);
  });

  onUnmounted(() => {
    clearInterval(bannerInterval);
  });

  return {
    banners,
    getBannerClass,
  };
};

export default useBannerHook;
