import { onMounted, ref } from "vue";
import TypesApiService from "../service/TypesApiService";

const useTypes = () => {
  const types = ref([]);

  const getTypes = async () => {
    const data = await TypesApiService.getAll();
    types.value = data ?? [];
  };

  onMounted(() => {
    getTypes();
  });

  return {
    types,
  };
};

export default useTypes;
