<script setup>
import { computed, onMounted, ref } from "vue";

const emit = defineEmits(["submit"]);

const validated = ref(false);

onMounted(() => {
  validated.value = false;
});

const validatedClass = computed(() => ({ "was-validated": validated.value }));
const onSubmit = (event) => {
  const form = event.currentTarget;
  if (form.checkValidity()) {
    emit("submit");
  }
  validated.value = true;
};
</script>

<template>
  <form
    id="items-form"
    class="needs-validation"
    :class="validatedClass"
    novalidate
    @submit.stop.prevent="onSubmit"
  >
    <slot></slot>
  </form>
</template>
