<script setup>
import { useRoute, useRouter } from "vue-router";
import { cartSum } from "../cart/CartStorage";

const route = useRoute();
const router = useRouter();
const routes = router.getRoutes() ?? [];
const indexPageLink = routes
  .filter((path) => path.redirect || "" === "/")
  .shift();
const pages = routes.filter((path) =>
  Object.prototype.hasOwnProperty.call(path.meta, "title"),
);
</script>

<template>
  <nav class="navbar navbar-expand-md my-navbar" data-bs-theme="dark">
    <div class="container-fluid">
      <RouterLink class="navbar-brand" :to="indexPageLink?.path ?? '/'">
        <i class="bi bi-cart2 d-inline-block align-top me-1 logo"></i>
        My Shop
      </RouterLink>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#main-navbar"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div id="main-navbar" class="collapse navbar-collapse">
        <ul class="navbar-nav me-auto link">
          <li v-for="page in pages" :key="page.path">
            <RouterLink
              class="nav-link"
              :class="{ active: route.path === page.path }"
              :to="page.path"
            >
              {{ page.meta.title }}
            </RouterLink>
          </li>
        </ul>
        <ul class="navbar-nav">
          <RouterLink class="navbar-brand" to="/cart">
            <i class="bi bi-cart2 d-inline-block align-top me-1 logo"></i>
            {{ cartSum }} &#8381;
          </RouterLink>
        </ul>
      </div>
    </div>
  </nav>
</template>

<style scoped>
.my-navbar {
  background-color: #3c3c3c !important;
}

.my-navbar .link a:hover {
  text-decoration: underline;
}

.my-navbar .logo {
  width: 26px;
  height: 26px;
  font-size: 26px;
}
</style>
