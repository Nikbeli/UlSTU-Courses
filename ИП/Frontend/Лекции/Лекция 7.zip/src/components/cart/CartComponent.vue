<script setup>
import imgPlaceholder from "../../assets/200.png";
import {
  addToCart,
  cartItems,
  cartSum,
  clearCart,
  removeFromCart,
} from "./CartStorage";

const itemSum = (item) => parseFloat(item.price * item.count).toFixed(2);
</script>

<template>
  <div class="d-flex flex-column align-items-center">
    <div class="mb-2 col-12 col-md-8 col-lg-6 d-flex align-items-center">
      <strong class="flex-fill">Корзина</strong>
      <button class="btn btn-danger" @click="clearCart">
        <i class="bi bi-x-lg"></i> Очистить
      </button>
    </div>
    <div
      v-for="cartItem in cartItems"
      :key="cartItem.id"
      class="card mb-2 col-12 col-md-8 col-lg-6"
    >
      <div
        class="card-body p-2 d-flex flex-column flex-sm-row align-items-center"
      >
        <div class="cart-item flex-fill">
          <img
            class="cart-image"
            :src="cartItem.image || imgPlaceholder"
            alt="Cart Image"
          />
          {{ cartItem.type.name }}
        </div>
        <div
          class="cart-item mt-2 mt-sm-0 d-flex flex-column align-items-center align-items-sm-end"
        >
          <div>
            {{ cartItem.price }} * {{ cartItem.count }} =
            {{ itemSum(cartItem) }}
          </div>
          <div
            class="btn-group mt-2 mt-sm-1"
            role="group"
            aria-label="Cart counter"
          >
            <button class="btn btn-primary" @click="addToCart(cartItem)">
              <i class="bi bi-plus-lg"></i>
            </button>
            <button class="btn btn-danger" @click="removeFromCart(cartItem)">
              <i class="bi bi-dash-lg"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="mb-2 col-12 col-md-8 col-lg-6 d-flex justify-content-end">
      <strong>Итого: {{ cartSum }} &#8381;</strong>
    </div>
  </div>
</template>

<style scoped>
.cart-image {
  width: 3.1rem;
  padding: 0.25rem;
  border-radius: 0.5rem;
}
.cart-item {
  height: auto;
}
</style>
