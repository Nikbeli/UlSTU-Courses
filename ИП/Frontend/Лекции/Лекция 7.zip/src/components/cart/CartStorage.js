import { computed, reactive } from "vue";

const CART_KEY = "localCart";

const loadCart = () => {
  const cartData = localStorage.getItem(CART_KEY);
  if (cartData) {
    return JSON.parse(cartData);
  }
  return [];
};

const cartStorage = reactive({
  cart: loadCart(),
});

const saveCart = () => {
  localStorage.setItem(CART_KEY, JSON.stringify(cartStorage.cart));
};

export const addToCart = (item) => {
  const existsItem = cartStorage.cart.find(
    (cartItem) => cartItem.id === item.id,
  );
  if (existsItem !== undefined) {
    existsItem.count += 1;
  } else {
    cartStorage.cart.push({ ...item, count: 1 });
  }
  saveCart();
};

export const removeFromCart = (item) => {
  const existsItem = cartStorage.cart.find(
    (cartItem) => cartItem.id === item.id,
  );
  if (existsItem !== undefined && existsItem.count > 1) {
    existsItem.count -= 1;
  } else {
    cartStorage.cart = cartStorage.cart.filter(
      (cartItem) => cartItem.id !== item.id,
    );
  }
  saveCart();
};

export const clearCart = () => {
  cartStorage.cart = [];
  saveCart();
};

export const cartSum = computed(() => {
  return parseFloat(
    cartStorage.cart.reduce((sum, cartItem) => {
      return sum + cartItem.price * cartItem.count;
    }, 0) ?? 0,
  ).toFixed(2);
});

export const cartItems = computed(() => [...cartStorage.cart]);
