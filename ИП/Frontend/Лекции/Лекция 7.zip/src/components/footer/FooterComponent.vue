<script setup>
const year = new Date().getFullYear();
</script>

<template>
  <footer
    className="my-footer mt-auto d-flex flex-shrink-0 justify-content-center align-items-center"
  >
    Автор, {{ year }}
  </footer>
</template>

<style scoped>
.my-footer {
  background-color: #9c9c9c;
  height: 32px;
  color: #fff;
}
</style>
