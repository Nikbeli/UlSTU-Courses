<script setup>
import FooterComponent from "./components/footer/FooterComponent.vue";
import NavigationComponent from "./components/navigation/NavigationComponent.vue";
</script>

<template>
  <NavigationComponent />
  <main class="container-fluid p-2">
    <RouterView />
  </main>
  <FooterComponent />
</template>
