import "bootstrap-icons/font/bootstrap-icons.min.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import { createApp } from "vue";
import { createRouter, createWebHistory } from "vue-router";
import ToastPlugin from "vue-toast-notification";
import "vue-toast-notification/dist/theme-bootstrap.css";
import App from "./App.vue";
import CartPage from "./pages/CartPage.vue";
import EditPage from "./pages/EditPage.vue";
import ErrorPage from "./pages/ErrorPage.vue";
import TestPage1 from "./pages/TestPage1.vue";
import TestPage2 from "./pages/TestPage2.vue";
import TestPage3 from "./pages/TestPage3.vue";
import TestPage4 from "./pages/TestPage4.vue";
import "./style.css";

const routes = [
  {
    path: "/",
    redirect: "/page1",
  },
  {
    path: "/page1",
    component: TestPage1,
    meta: {
      title: "Главная страница",
    },
  },
  {
    path: "/page2",
    component: TestPage2,
    meta: {
      title: "Вторая страница",
    },
  },
  {
    path: "/page3",
    component: TestPage3,
    meta: {
      title: "Третья страница",
    },
  },
  {
    path: "/page4",
    component: TestPage4,
    meta: {
      title: "Четвертая страница",
    },
  },
  {
    path: "/page-edit/:id?",
    component: EditPage,
  },
  {
    path: "/cart",
    component: CartPage,
  },
  {
    path: "/:notFound",
    component: ErrorPage,
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

const app = createApp(App);
app.use(router);
app.use(ToastPlugin, { position: "top" });
app.mount("#root");
