<script setup>
import BannerComponent from "../components/banner/BannerComponent.vue";
</script>
<template>
  <BannerComponent />
  <h1>Пример web-страницы.</h1>
  <h2>1. Структурные элементы</h2>
  <p>
    <b>Полужирное начертание <i>курсив</i></b>
  </p>
  <p>
    Абзац 2
    <RouterLink to="/page2">Ссылка</RouterLink>
  </p>
  <h3>1.1. Списки</h3>
  <p>Список маркированный:</p>
  <ul>
    <li>
      <a href="/page2" target="_blank">Элемент списка 1</a>
    </li>
    <li>
      <RouterLink to="/page2" target="_blank">Элемент списка 2</RouterLink>
    </li>
    <li>
      <a href="/page2">Элемент списка 3</a>
    </li>
    <li>
      <RouterLink to="/page2">Элемент списка 4</RouterLink>
    </li>
    <li>...</li>
  </ul>
  <p>Список нумерованный:</p>
  <ol>
    <li>Элемент списка 1</li>
    <li>Элемент списка 2</li>
    <li>...</li>
  </ol>
</template>
