<template>
  <div class="mt-3 row justify-content-center">
    <div class="col-12 col-md-8 col-lg-6 d-flex flex-column">
      <h1 class="text-center"><i class="bi bi-bug-fill"></i> 404</h1>
      <RouterLink to="/" class="btn btn-primary">На главную</RouterLink>
    </div>
  </div>
</template>
