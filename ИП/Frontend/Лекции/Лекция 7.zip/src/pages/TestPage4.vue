<script setup>
import LinesComponent from "../components/lines/table/LinesComponent.vue";
</script>

<template>
  <LinesComponent />
</template>
