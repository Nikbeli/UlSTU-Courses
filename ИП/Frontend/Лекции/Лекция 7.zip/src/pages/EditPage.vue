<script setup>
import { useRoute } from "vue-router";
import LinesForm from "../components/lines/form/LinesForm.vue";

const route = useRoute();
const currentId = parseInt(route.params.id || 0, 10);
</script>

<template>
  <LinesForm :lines-id="currentId" />
</template>
