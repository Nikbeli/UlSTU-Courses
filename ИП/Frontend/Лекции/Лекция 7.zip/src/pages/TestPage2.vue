<script setup>
import ulstuLogo from "../assets/logo.png";
</script>

<template>
  <p className="text-center">
    Вторая страница содержит пример рисунка (рис. 1) и таблицы (таб. 1).
  </p>
  <div className="text-center">
    <img :src="ulstuLogo" alt="logo" width="128" />
    <br />
    Рис. 1. Пример рисунка.
  </div>
  <div className="mt-3 row justify-content-center">
    <table class="table table-bordered w-50">
      <caption>
        Таблица 1. Пример таблицы.
      </caption>
      <thead>
        <tr>
          <th className="w-25">Номер</th>
          <th>ФИО</th>
          <th className="w-25">Телефон</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>Иванов</td>
          <td>89999999999</td>
        </tr>
        <tr>
          <td>2</td>
          <td>Петров</td>
          <td>89999999991</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
