<script setup>
import { reactive, ref } from "vue";

const someValue = "Некоторое значение";
const validated = ref(false);
const formData = reactive({
  lastname: "",
  firstname: "",
  email: "",
  password: "",
  date: "",
  disabled: someValue,
  readonly: someValue,
  color: "#ff0055",
  checkbox1: false,
  checkbox2: false,
  radio1: false,
  radio2: false,
  selected: "",
});

const handleSubmit = (event) => {
  const form = event.currentTarget;
  event.preventDefault();
  event.stopPropagation();
  if (form.checkValidity() !== false) {
    console.log(formData);
  }
  validated.value = true;
};
</script>

<template>
  <div class="row justify-content-center">
    <form
      class="col-md-6 m-0 needs-validation"
      :class="{ 'was-validated': validated }"
      novalidate
      @submit="handleSubmit"
    >
      <div class="mb-2">
        <label class="form-label" for="lastname">Фамилия</label>
        <input
          id="lastname"
          v-model="formData.lastname"
          name="lastname"
          class="form-control"
          type="text"
          required
        />
        <div class="valid-feedback">Фамилия заполнена</div>
        <div class="invalid-feedback">Фамилия не заполнена</div>
      </div>
      <div class="mb-2">
        <label class="form-label" for="firstname">Имя</label>
        <input
          id="firstname"
          v-model="formData.firstname"
          name="firstname"
          class="form-control"
          type="text"
          required
        />
      </div>
      <div class="mb-2">
        <label class="form-label" for="email">E-mail</label>
        <input
          id="email"
          v-model="formData.email"
          name="email"
          class="form-control"
          type="email"
          placeholder="name@example.ru"
          required
        />
      </div>
      <div class="mb-2">
        <label class="form-label" for="password">Пароль</label>
        <input
          id="password"
          v-model="formData.password"
          name="password"
          class="form-control"
          type="password"
          required
        />
      </div>
      <div class="mb-2">
        <label class="form-label" for="date">Дата</label>
        <input
          id="date"
          v-model="formData.date"
          name="date"
          class="form-control"
          type="date"
          required
        />
      </div>
      <div class="mb-2">
        <label class="form-label" for="disabled">Выключенный компонент</label>
        <input
          id="disabled"
          v-model="formData.disabled"
          name="disabled"
          class="form-control"
          type="text"
          disabled
        />
      </div>
      <div class="mb-2">
        <label class="form-label" for="readonly"
          >Компонент только для чтения</label
        >
        <input
          id="readonly"
          v-model="formData.readonly"
          name="readonly"
          class="form-control"
          type="text"
          readonly
        />
      </div>
      <div class="mb-2">
        <label class="form-label" for="color">Выбор цвета</label>
        <input
          id="color"
          v-model="formData.color"
          name="color"
          type="color"
          class="form-control form-control-color"
        />
      </div>
      <div class="mb-2 d-md-flex flex-md-row">
        <div class="form-check me-md-3">
          <input
            id="checkbox1"
            v-model="formData.checkbox1"
            class="form-check-input"
            name="checkbox1"
            type="checkbox"
            required
          />
          <label class="form-check-label" for="checkbox1">Флажок 1</label>
        </div>
        <div class="form-check">
          <input
            id="checkbox2"
            v-model="formData.checkbox2"
            class="form-check-input"
            name="checkbox2"
            type="checkbox"
          />
          <label class="form-check-label" for="checkbox2">Флажок 2</label>
        </div>
      </div>
      <div class="mb-2 d-md-flex flex-md-row">
        <div class="form-check me-md-3">
          <input
            id="radio1"
            v-model="formData.radio1"
            class="form-check-input"
            type="radio"
            name="radio-example"
          />
          <label class="form-check-label" for="radio1">Переключатель 1</label>
        </div>
        <div class="form-check">
          <input
            id="radio2"
            v-model="formData.radio2"
            class="form-check-input"
            type="radio"
            name="radio-example"
          />
          <label class="form-check-label" for="radio2">Переключатель 2</label>
        </div>
      </div>
      <div class="mb-2">
        <select
          v-model="formData.selected"
          class="form-select"
          name="selected"
          required
        >
          <option value="" selected>Выберите значение</option>
          <option value="1">Один</option>
          <option value="2">Два</option>
          <option value="3">Три</option>
        </select>
      </div>
      <div class="text-center">
        <button class="btn btn-primary w-50" type="submit">Отправить</button>
      </div>
    </form>
  </div>
</template>
