<script setup>
import CartComponent from "../components/cart/CartComponent.vue";
</script>

<template>
  <CartComponent />
</template>
