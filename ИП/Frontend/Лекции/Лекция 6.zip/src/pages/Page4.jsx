import Lines from '../components/lines/table/Lines.jsx';

const Page4 = () => {
    return (
        <Lines />
    );
};

export default Page4;
