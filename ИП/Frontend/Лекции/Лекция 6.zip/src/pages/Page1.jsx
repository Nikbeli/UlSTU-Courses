import { Link } from 'react-router-dom';
import Banner from '../components/banner/Banner.jsx';

const Page1 = () => {
    return (
        <>
            <Banner />
            <>
                <h1>Пример web-страницы.</h1>
                <h2>1. Структурные элементы</h2>
                <p><b>Полужирное начертание <i>курсив</i></b></p>
                <p>Абзац 2 <Link to='/page2'>Ссылка</Link></p>
                <h3>1.1. Списки</h3>
                <p>
                    Список маркированный:
                </p>
                <ul>
                    <li>
                        <a href='/page2' target='_blank'>Элемент списка 1</a>
                    </li>
                    <li>
                        <Link to="/page2" target='_blank'>Элемент списка 2</Link>
                    </li>
                    <li>...</li>
                </ul>
                <p>
                    Список нумерованный:
                </p>
                <ol>
                    <li>Элемент списка 1</li>
                    <li>Элемент списка 2</li>
                    <li>...</li>
                </ol>
            </>
        </>
    );
};

export default Page1;
