import './Banner.css';
import useBannerHook from './BannerHook';

const Banner = () => {
    const { banners, getBannerClass } = useBannerHook();

    return (
        <div id='banner'>
            {
                banners.map((banner, index) =>
                    <img key={index} className={getBannerClass(index)} src={banner} alt={`banner${index}`} />)
            }
        </div >
    );
};

export default Banner;
